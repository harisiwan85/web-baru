"""Up-4ever uploader implementation using web scraping."""
import os
import re
import math
import random
import requests
from typing import Callable, Optional, Dict, Any
from pathlib import Path
from bs4 import BeautifulSoup
from uploaders.base import BaseUploader
from core.models import UploadResult, UploadStatus


class _UploadCancelled(Exception):
    """Raised when the user cancels an in-flight upload."""
    pass


class _ChunkReader:
    """File-like reader over a byte range of an open file, for streaming one chunk."""

    def __init__(self, file_obj, start, length, check_cancel=None):
        file_obj.seek(start)
        self._f = file_obj
        self._length = length
        self._remaining = length
        self._check_cancel = check_cancel

    def read(self, size=-1):
        if self._check_cancel and self._check_cancel():
            raise _UploadCancelled("Upload Cancelled")
        if self._remaining <= 0:
            return b""
        if size is None or size < 0:
            size = self._remaining
        data = self._f.read(min(size, self._remaining))
        self._remaining -= len(data)
        return data

    def __len__(self):
        return self._length


class Up4EverUploader(BaseUploader):
    """Up-4ever file uploader using cookies and web scraping."""

    BASE_URL = "https://www.up-4ever.net"
    UPLOAD_URL = "https://www.up-4ever.net/upload/"

    def __init__(self):
        """Initialize Up-4ever uploader."""
        super().__init__("Up-4ever")
        self._cookies: Optional[Dict[str, str]] = None
        # Don't create session here, create fresh session for each upload
        self._base_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }

    def _get_session(self):
        """Create a fresh session for upload to avoid connection pooling issues."""
        session = requests.Session()
        session.headers.update(self._base_headers)

        # Apply cookies if available
        if self._cookies:
            if isinstance(self._cookies, dict):
                for name, value in self._cookies.items():
                    session.cookies.set(name, value)
            elif isinstance(self._cookies, list):
                for cookie_item in self._cookies:
                    if isinstance(cookie_item, dict):
                        name = cookie_item.get('name') or cookie_item.get('Name')
                        value = cookie_item.get('value') or cookie_item.get('Value')
                        if name and value:
                            session.cookies.set(name, value)

        return session

    def set_credentials(self, credentials: Dict[str, Any]):
        """Set session cookies without validation."""
        cookies = credentials.get('cookies', {})
        if not cookies:
            return

        self._cookies = cookies
        self._credentials = credentials

    def authenticate(self, credentials: Dict[str, Any]) -> bool:
        """Authenticate using cookies and validate login.

        Args:
            credentials: Dict containing 'cookies' (dict or list)

        Returns:
            True if cookies are valid and logged in
        """
        self.set_credentials(credentials)
        if not self._cookies:
            return False

        # Test login status by accessing home page
        try:
            session = self._get_session()

            # Check if cookies were actually set
            if not list(session.cookies):
                return False

            response = session.get(self.BASE_URL, timeout=15)
            if response.status_code != 200:
                return False

            # Check for login indicators
            content = response.text
            content_lower = content.lower()

            # Logged-in members see "Logout" / "My Account" in the header
            if "logout" in content_lower or "my account" in content_lower:
                return True

            # Also check for account balance or space info which are member-only
            if "balance:" in content_lower or "used space:" in content_lower:
                return True

            # Logged-out header is explicitly rendered (classic XFS nav links)
            if 'class="u4h-login"' in content or "<!-- logged out -->" in content:
                return False

            # Unknown markup: don't block upload on a heuristic
            return True
        except Exception:
            return False

    def is_authenticated(self) -> bool:
        """Check if authenticated.

        Returns:
            True if cookies are set
        """
        return self._cookies is not None

    def _start_upload(self, session, file_name: str, file_size: int) -> Optional[Dict[str, Any]]:
        """Ask the site for an upload server (current XFS 'xfspro' flow).

        POST / with op=start_upload returns JSON like:
            {"url": "https://s9.up4ever.download/cgi-bin", "plugin": "xfspro"}

        The upload server host rotates (s9/s10/s11/... on up4ever.download),
        so it must be fetched fresh for every upload.
        """
        data = {
            'op': 'start_upload',
            'file_name': file_name,
            'file_descr': '',
            'file_public': 1,
            'file_size': file_size,
        }
        response = session.post(self.BASE_URL + "/", data=data, timeout=30)
        if response.status_code != 200:
            return None
        try:
            result = response.json()
        except Exception:
            return None
        if not isinstance(result, dict) or not result.get('url'):
            return None
        return {
            'url': result['url'].rstrip('/'),
            'plugin': result.get('plugin'),
            'sess_id': result.get('sess_id', ''),
        }

    def _get_sess_id(self, session) -> str:
        """Fetch the upload page and extract the server-rendered sess_id.

        The site renders a session id into the upload page (classic form
        hidden field and the Angular ng-init). The browser passes this value
        to the import_file call, and it is what ties an upload to the
        logged-in member account. Without it, files are imported anonymously.

        Returns:
            The sess_id string, or "" if it could not be found.
        """
        try:
            page = session.get(self.UPLOAD_URL, timeout=30)
            if page.status_code != 200:
                page = session.get(f"{self.BASE_URL}/?op=upload", timeout=30)
            if page.status_code != 200:
                return ""
            html = page.text
            # 1. Classic form hidden field: name="sess_id" value="..."
            match = re.search(r'name="sess_id"\s+value="([^"]*)"', html)
            if match:
                return match.group(1)
            # 2. Angular initializer: ng-init="sess_id = '...'"
            match = re.search(r"ng-init=\"sess_id\s*=\s*'([^']*)'\"", html)
            if match:
                return match.group(1)
        except Exception:
            pass
        return ""

    def _is_ok_json(self, resp) -> bool:
        """Check a response body is JSON with status OK."""
        try:
            data = resp.json()
        except Exception:
            return False
        return isinstance(data, dict) and data.get('status') == 'OK'

    def _chunked_upload(self, session, cgi_url: str, file_path: str, file_name: str,
                        file_size: int, progress_callback, check_cancel,
                        start_progress: int = 10, end_progress: int = 95) -> str:
        """Upload a file via the site's chunked PUT API (put_chunk_mt.cgi).

        Mirrors the site's own upload-xfspro-mt.js: generate a 16-digit SID,
        PUT raw byte ranges with X-Upload-SID / X-Seek-To headers, then return
        the SID for the import_file call.

        Returns:
            The upload SID used to import the file.
        """
        sid = "".join(random.choices("0123456789", k=16))

        # Same chunking rules as the site: clamp(size/4) to [1MB, 100MB]
        chunk_size = max(1 * 1024 * 1024, min(100 * 1024 * 1024, math.ceil(file_size / 4)))
        chunk_count = max(1, math.ceil(file_size / chunk_size)) if file_size > 0 else 1

        sent = [0]
        progress_range = end_progress - start_progress

        def report():
            if progress_callback:
                if file_size > 0:
                    pct = start_progress + (sent[0] / file_size * progress_range)
                else:
                    pct = end_progress
                progress_callback(min(int(pct), end_progress))

        headers_base = {
            'Content-Type': 'application/octet-stream',
            'X-Upload-SID': sid,
            'Referer': self.UPLOAD_URL,
            'Origin': self.BASE_URL,
            'User-Agent': session.headers.get('User-Agent'),
        }

        with open(file_path, 'rb') as f:
            for index in range(chunk_count):
                if check_cancel and check_cancel():
                    raise _UploadCancelled("Upload Cancelled")

                start = index * chunk_size
                length = min(chunk_size, file_size - start)
                headers = dict(headers_base)
                headers['X-Seek-To'] = str(start)
                headers['Content-Length'] = str(length)

                last_error = "unknown error"
                ok = False
                for attempt in range(3):
                    # Fresh reader per attempt so a retry re-sends the whole chunk
                    reader = _ChunkReader(f, start, length, check_cancel)
                    try:
                        resp = session.put(
                            f"{cgi_url}/put_chunk_mt.cgi",
                            data=reader,
                            headers=headers,
                            timeout=3600,
                        )
                        if resp.status_code in (200, 201) and self._is_ok_json(resp):
                            ok = True
                            break
                        last_error = f"chunk {index} rejected (HTTP {resp.status_code}): {resp.text[:120]}"
                    except _UploadCancelled:
                        raise
                    except Exception as e:
                        last_error = str(e)

                if not ok:
                    raise RuntimeError(f"Upload failed: {last_error}")

                sent[0] += length
                report()

        return sid

    def _import_file(self, session, cgi_url: str, sid: str, file_name: str, sess_id: str = "") -> Dict[str, Any]:
        """Finalize the upload via api.cgi op=import_file.

        Returns:
            The parsed JSON result (status/file_code/links).
        """
        data = {
            'op': 'import_file',
            'sid': sid,
            'fname': file_name,
            'file_descr': '',
            'file_public': 1,
        }
        if sess_id:
            data['sess_id'] = sess_id

        resp = session.post(f"{cgi_url}/api.cgi", data=data, timeout=60)
        if resp.status_code != 200:
            raise RuntimeError(f"Import failed (HTTP {resp.status_code}): {resp.text[:120]}")
        try:
            result = resp.json()
        except Exception:
            raise RuntimeError(f"Import returned invalid response: {resp.text[:120]}")
        if not isinstance(result, dict) or result.get('status') != 'OK':
            raise RuntimeError(f"Import failed: {resp.text[:200]}")
        return result

    def _extract_link(self, result: Dict[str, Any]):
        """Extract download link + file code from an import_file response."""
        file_code = result.get('file_code')
        links = result.get('links') or {}
        download_link = links.get('download_link')
        if not download_link and file_code:
            download_link = f"{self.BASE_URL}/{file_code}"
        if download_link and download_link.rstrip('/') == self.BASE_URL.rstrip('/'):
            download_link = None
        return download_link, file_code

    def _get_classic_form(self, session):
        """Fetch the upload page and parse the classic multipart upload form.

        Returns:
            (action_url, form_fields, file_field_name, status_code)
            status_code is only set if the page could not be fetched.
        """
        upload_page = session.get(self.UPLOAD_URL, timeout=30)
        if upload_page.status_code != 200:
            alt_url = f"{self.BASE_URL}/?op=upload"
            upload_page = session.get(alt_url, timeout=30)

        if upload_page.status_code != 200:
            return None, None, None, upload_page.status_code

        soup = BeautifulSoup(upload_page.content, 'html.parser')

        # Common form IDs/names for XFS
        form_identifiers = [
            {'id': 'my-dropzone'},   # New XFS / Dropzone
            {'id': 'uploadfile'},    # Common XFS
            {'id': 'fileupload'},
            {'name': 'file_upload'},
            {'id': 'upload_form'},
            {'id': 'upload_file_classic'}  # Current Up-4ever classic form
        ]

        upload_form = None
        for attr in form_identifiers:
            upload_form = soup.find('form', attr)
            if upload_form:
                break

        if not upload_form:
            # Fallback: Find any form with a file input and POST method
            for form in soup.find_all('form'):
                if form.get('method', '').upper() == 'POST' and form.find('input', {'type': 'file'}):
                    upload_form = form
                    break

        if not upload_form:
            # One last try: Any form with enctype multipart
            upload_form = soup.find('form', {'enctype': 'multipart/form-data'})

        if not upload_form:
            forms_found = [f.get('id') or f.get('name') or "unnamed" for f in soup.find_all('form')]
            raise RuntimeError(
                f"Could not find upload form. Forms on page: {', '.join(forms_found)}. "
                f"Page title: {soup.title.text if soup.title else 'No Title'}"
            )

        # The form action is the authoritative upload CGI URL (includes query
        # params like ?upload_type=file&utype=anon on the current site).
        action = upload_form.get('action') or ""
        if action.startswith('//'):
            action = "https:" + action
        elif action.startswith('/'):
            action = self.BASE_URL + action

        # Extract form fields and file field name
        form_data = {}
        file_field_name = "files[]"  # Default for XFS
        for input_field in upload_form.find_all('input'):
            name = input_field.get('name')
            if not name:
                continue

            if input_field.get('type') == 'file':
                file_field_name = name
            else:
                form_data[name] = input_field.get('value', '')

        return action, form_data, file_field_name, None

    def _classic_upload(self, session, file_path: str, file_name: str,
                        progress_callback, check_cancel):
        """Fallback: classic XFS multipart upload via the upload page form.

        Returns:
            (download_link, file_code)
        """
        action, form_data, file_field_name, status_code = self._get_classic_form(session)
        if status_code is not None:
            raise RuntimeError(f"Failed to access upload page (Status: {status_code})")
        if not action:
            raise RuntimeError("Upload page has no form action")

        # Add Referer and Origin to avoid 403
        headers = {
            'Referer': self.UPLOAD_URL,
            'Origin': self.BASE_URL,
            'User-Agent': session.headers.get('User-Agent')
        }

        with open(file_path, 'rb') as f:
            files = {
                file_field_name: (file_name, f, 'application/octet-stream')
            }
            upload_response = self._stream_upload_with_session(
                session,
                action,
                files,
                form_data,
                headers,
                progress_callback,
                start_progress=10,
                end_progress=95,
                verify=True,
                check_cancel=check_cancel
            )

        if upload_response.status_code not in [200, 201, 302]:
            raise RuntimeError(f"Upload request failed with status {upload_response.status_code}")

        response_text = upload_response.text
        download_link = None
        file_code = None

        # Try to parse JSON response (XFS usually returns JSON for uploads)
        try:
            data = upload_response.json()
            if isinstance(data, list) and len(data) > 0:
                data = data[0]

            file_code = data.get('file_code') or data.get('code')
            if file_code:
                download_link = f"{self.BASE_URL}/{file_code}"
            elif data.get('url'):
                download_link = data['url']
        except Exception:
            pass

        # Look for file_code in redirect or HTML
        if not download_link:
            match = re.search(r'fn=([a-z0-9]+)', response_text)
            if match:
                file_code = match.group(1)
                download_link = f"{self.BASE_URL}/{file_code}"

        if not download_link:
            match = re.search(r'"file_code":"([a-z0-9]+)"', response_text)
            if match:
                file_code = match.group(1)
                download_link = f"{self.BASE_URL}/{file_code}"

        if download_link:
            if download_link.rstrip('/') == self.BASE_URL.rstrip('/'):
                download_link = None

        if not download_link:
            raise RuntimeError(f"Upload success but failed to extract link. Response: {response_text[:100]}")

        return download_link, file_code

    def upload(self, file_path: str, progress_callback: Optional[Callable[[int], None]] = None, check_cancel: Optional[Callable[[], bool]] = None) -> UploadResult:
        """Upload file to Up-4ever.

        Args:
            file_path: Path to file to upload
            progress_callback: Progress callback (0-100)
            check_cancel: Callback to check if the upload should be cancelled

        Returns:
            UploadResult with download link
        """
        if not self.is_authenticated():
            return self._create_result(UploadStatus.FAILED, error_message="Not authenticated")

        # Create fresh session for this upload to avoid connection pooling issues
        session = self._get_session()

        try:
            file_path_obj = Path(file_path)
            if not file_path_obj.exists():
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"File not found: {file_path}"
                )

            file_name = file_path_obj.name
            file_size = file_path_obj.stat().st_size

            if check_cancel and check_cancel():
                return self._create_result(UploadStatus.FAILED, error_message="Cancelled")

            if progress_callback:
                progress_callback(5)

            # 1. Get upload server via the current start_upload API
            prerequest = None
            try:
                prerequest = self._start_upload(session, file_name, file_size)
            except Exception:
                prerequest = None

            if progress_callback:
                progress_callback(10)

            # The server-rendered sess_id is what ties the upload to the
            # logged-in member account (the site's own JS sends it with the
            # import_file call). Without it, files are imported anonymously.
            sess_id = self._get_sess_id(session) or prerequest.get('sess_id', '') if prerequest else ""

            primary_error = None
            if prerequest and prerequest.get('plugin') in (None, 'xfspro'):
                try:
                    # 2. Stream the file as chunks (put_chunk_mt.cgi)
                    sid = self._chunked_upload(
                        session, prerequest['url'], file_path, file_name, file_size,
                        progress_callback, check_cancel, 10, 95
                    )

                    if progress_callback:
                        progress_callback(96)

                    # 3. Finalize and get the download link (api.cgi)
                    result = self._import_file(
                        session, prerequest['url'], sid, file_name, sess_id
                    )
                    download_link, file_code = self._extract_link(result)
                    if not download_link:
                        raise RuntimeError("Upload succeeded but no download link returned")

                    if progress_callback:
                        progress_callback(100)
                    return self._create_result(UploadStatus.COMPLETED, download_link=download_link, file_id=file_code)
                except _UploadCancelled:
                    return self._create_result(UploadStatus.FAILED, error_message="Cancelled")
                except Exception as e:
                    # Remember the real error in case the fallback also fails
                    primary_error = str(e)

            # 2b. Fallback: classic multipart form upload
            try:
                download_link, file_code = self._classic_upload(
                    session, file_path, file_name, progress_callback, check_cancel
                )
                if progress_callback:
                    progress_callback(100)
                return self._create_result(UploadStatus.COMPLETED, download_link=download_link, file_id=file_code)
            except _UploadCancelled:
                return self._create_result(UploadStatus.FAILED, error_message="Cancelled")
            except Exception as e:
                message = str(e)
                if primary_error:
                    message = f"{message} (chunked API error: {primary_error})"
                return self._create_result(UploadStatus.FAILED, error_message=f"Upload error: {message}")

        except Exception as e:
            return self._create_result(UploadStatus.FAILED, error_message=f"Upload error: {str(e)}")
