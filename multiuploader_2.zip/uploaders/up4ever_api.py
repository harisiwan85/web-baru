"""Up-4ever official REST API uploader implementation.

Docs: https://www.up-4ever.net/pages/api

Upload flow:
  1. GET  /api/upload/server?key=KEY        -> result URL + sess_id + utype
  2. POST result URL (multipart)            -> [{"file_code": "...", "file_status": "OK"}]
  3. Public page: https://www.up-4ever.net/FILE_CODE
"""
import requests
from typing import Callable, Optional, Dict, Any
from pathlib import Path
from uploaders.base import BaseUploader
from core.models import UploadResult, UploadStatus


class Up4EverApiUploader(BaseUploader):
    """Up-4ever file uploader using the official REST API (key auth)."""

    SITE_URL = "https://www.up-4ever.net"
    API_BASE_URL = "https://www.up-4ever.net/api"

    def __init__(self):
        """Initialize Up-4ever API uploader."""
        super().__init__("Up-4ever API")
        self._api_key: Optional[str] = None
        self._session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                          '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        })

    def set_credentials(self, credentials: Dict[str, Any]):
        """Set API key without validation."""
        self._api_key = credentials.get('api_key')
        self._credentials = credentials

    def authenticate(self, credentials: Dict[str, Any]) -> bool:
        """Validate the API key using the account/info endpoint.

        Args:
            credentials: Dict containing 'api_key'

        Returns:
            True if the key is valid
        """
        self.set_credentials(credentials)
        if not self._api_key:
            return False

        try:
            response = requests.get(
                f"{self.API_BASE_URL}/account/info",
                params={'key': self._api_key},
                timeout=15
            )
            if response.status_code != 200:
                return False
            data = response.json()
            return isinstance(data, dict) and data.get('msg') == 'OK'
        except Exception:
            return False

    def is_authenticated(self) -> bool:
        """Check if authenticated.

        Returns:
            True if API key is set
        """
        return self._api_key is not None

    def _get_upload_server(self) -> Optional[Dict[str, Any]]:
        """Request an upload server and short-lived session.

        Returns:
            Dict with 'url', 'sess_id' and 'utype', or None on failure.
        """
        response = requests.get(
            f"{self.API_BASE_URL}/upload/server",
            params={'key': self._api_key},
            timeout=30
        )
        if response.status_code != 200:
            return None
        try:
            data = response.json()
        except Exception:
            return None
        if not isinstance(data, dict) or data.get('msg') != 'OK':
            return None
        upload_url = data.get('result')
        if not upload_url:
            return None
        return {
            'url': upload_url,
            'sess_id': data.get('sess_id', ''),
            'utype': data.get('utype', 'reg'),
        }

    def upload(self, file_path: str, progress_callback: Optional[Callable[[int], None]] = None,
               check_cancel: Optional[Callable[[], bool]] = None) -> UploadResult:
        """Upload file to Up-4ever via the REST API.

        Args:
            file_path: Path to file to upload
            progress_callback: Progress callback (0-100)
            check_cancel: Callback to check if the upload should be cancelled

        Returns:
            UploadResult with download link
        """
        if not self.is_authenticated():
            return self._create_result(UploadStatus.FAILED, error_message="Not authenticated")

        try:
            file_path_obj = Path(file_path)
            if not file_path_obj.exists():
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"File not found: {file_path}"
                )

            file_name = file_path_obj.name

            if check_cancel and check_cancel():
                return self._create_result(UploadStatus.FAILED, error_message="Cancelled")

            if progress_callback:
                progress_callback(5)

            # Step 1: ask for an upload server + session
            server = self._get_upload_server()
            if not server:
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message="Failed to get upload server (check API key / upload scope)"
                )

            if progress_callback:
                progress_callback(10)

            # Step 2: POST the file (multipart) to the upload server
            data = {
                'sess_id': server['sess_id'],
                'ajax': '1',
                'utype': server['utype'],
            }
            files = {
                'file_0': (file_name, open(file_path, 'rb'), 'application/octet-stream')
            }

            headers = {
                'User-Agent': self._session.headers.get('User-Agent'),
                'Origin': self.SITE_URL,
                'Referer': self.SITE_URL + '/',
            }

            try:
                upload_response = self._stream_upload(
                    server['url'],
                    files,
                    data,
                    headers,
                    progress_callback,
                    start_progress=10,
                    end_progress=95,
                    verify=True,
                    check_cancel=check_cancel
                )
            finally:
                for f_info in files.values():
                    f_info[1].close()

            if upload_response.status_code not in [200, 201]:
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"Upload request failed with status {upload_response.status_code}"
                )

            # Step 3: parse the file code from the response
            try:
                response_data = upload_response.json()
            except ValueError:
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"Invalid JSON response: {upload_response.text[:100]}"
                )

            if isinstance(response_data, list):
                if not response_data:
                    return self._create_result(
                        UploadStatus.FAILED,
                        error_message="Upload returned an empty response"
                    )
                response_data = response_data[0]

            file_code = None
            if isinstance(response_data, dict):
                file_code = response_data.get('file_code')
                file_status = response_data.get('file_status', '').upper()
                if file_status and file_status != 'OK':
                    return self._create_result(
                        UploadStatus.FAILED,
                        error_message=f"Upload failed: {file_status}"
                    )

            if not file_code:
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"Upload finished but no file code returned: {str(response_data)[:100]}"
                )

            download_link = f"{self.SITE_URL}/{file_code}"

            if progress_callback:
                progress_callback(100)

            return self._create_result(
                UploadStatus.COMPLETED,
                download_link=download_link,
                file_id=file_code
            )

        except requests.exceptions.Timeout:
            return self._create_result(UploadStatus.FAILED, error_message="Upload timeout")
        except Exception as e:
            return self._create_result(UploadStatus.FAILED, error_message=f"Upload error: {str(e)}")
