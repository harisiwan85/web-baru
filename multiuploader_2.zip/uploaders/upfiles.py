"""Upfiles.com API uploader implementation."""
import os
import requests
from typing import Callable, Optional, Dict, Any
from pathlib import Path
from uploaders.base import BaseUploader
from core.models import UploadResult, UploadStatus


class UpfilesUploader(BaseUploader):
    """Upfiles.com file uploader using their API."""
    
    API_ENDPOINT = "https://api.upfiles.com/upload"
    
    def __init__(self):
        """Initialize Upfiles uploader."""
        super().__init__("Upfiles")
        self._token: Optional[str] = None
    
    def set_credentials(self, credentials: Dict[str, Any]):
        """Set API token without validation."""
        self._token = credentials.get('api_key')  # Use 'api_key' to match system convention
        self._credentials = credentials

    def authenticate(self, credentials: Dict[str, Any]) -> bool:
        """Authenticate with API token and validate.
        
        Args:
            credentials: Dict containing 'token'
            
        Returns:
            True if token is valid
        """
        self.set_credentials(credentials)
        if not self._token:
            return False
        
        # Test token by making a simple request
        # Since there's no explicit test endpoint, we'll just check if token is set
        # Actual validation will happen during upload
        return True
    
    def is_authenticated(self) -> bool:
        """Check if authenticated.
        
        Returns:
            True if token is set
        """
        return self._token is not None
    
    def upload(self, file_path: str, progress_callback: Optional[Callable[[int], None]] = None, 
               check_cancel: Optional[Callable[[], bool]] = None) -> UploadResult:
        """Upload file to Upfiles.com.
        
        Args:
            file_path: Path to file to upload
            progress_callback: Progress callback (0-100)
            check_cancel: Callback to check if the upload should be cancelled
            
        Returns:
            UploadResult with download link
        """
        if not self.is_authenticated():
            return self._create_result(
                UploadStatus.FAILED,
                error_message="Not authenticated"
            )
        
        try:
            file_path_obj = Path(file_path)
            if not file_path_obj.exists():
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"File not found: {file_path}"
                )
            
            file_name = file_path_obj.name
            
            if check_cancel and check_cancel():
                return self._create_result(UploadStatus.FAILED, error_message="Cancelled")

            if progress_callback:
                progress_callback(5)
            
            # Prepare upload data
            data = {
                'token': self._token
            }
            
            # Optional: folder_alias can be added if needed
            # data['folder_alias'] = 'your_folder_alias'
            
            files = {
                'file': (file_name, open(file_path, 'rb'), 'application/octet-stream')
            }
            
            if progress_callback:
                progress_callback(10)
            
            # Use streaming upload helper for real-time progress
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            # Streaming upload with progress tracking
            upload_response = self._stream_upload(
                self.API_ENDPOINT,
                files,
                data,
                headers,
                progress_callback,
                start_progress=10,
                end_progress=90,
                verify=True,
                check_cancel=check_cancel
            )
            
            # Close file objects
            for f_info in files.values():
                f_info[1].close()
            
            if upload_response.status_code not in [200, 201]:
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"Upload request failed with status {upload_response.status_code}"
                )
            
            # Parse response
            try:
                response_data = upload_response.json()
                
                # Extract download link from response
                # The API should return a JSON with the file URL
                download_link = None
                
                # Try different possible response formats
                if isinstance(response_data, dict):
                    # Common response formats
                    download_link = (
                        response_data.get('url') or 
                        response_data.get('download_url') or 
                        response_data.get('file_url') or
                        response_data.get('link')
                    )
                    
                    # Check for success status
                    if 'success' in response_data and not response_data['success']:
                        error_msg = response_data.get('error') or response_data.get('message') or 'Upload failed'
                        return self._create_result(
                            UploadStatus.FAILED,
                            error_message=error_msg
                        )
                
                if download_link:
                    if progress_callback:
                        progress_callback(100)
                    return self._create_result(
                        UploadStatus.COMPLETED,
                        download_link=download_link
                    )
                else:
                    return self._create_result(
                        UploadStatus.FAILED,
                        error_message=f"Upload success but failed to extract link. Response: {str(response_data)[:100]}"
                    )
                    
            except ValueError:
                # Response is not JSON
                response_text = upload_response.text
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"Invalid JSON response: {response_text[:100]}"
                )
            
        except requests.exceptions.Timeout:
            return self._create_result(
                UploadStatus.FAILED,
                error_message="Upload timeout"
            )
        except Exception as e:
            return self._create_result(
                UploadStatus.FAILED,
                error_message=f"Upload error: {str(e)}"
            )
