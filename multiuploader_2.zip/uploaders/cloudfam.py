"""CloudFam API uploader implementation."""
import os
import requests
from typing import Callable, Optional, Dict, Any
from pathlib import Path
from uploaders.base import BaseUploader
from core.models import UploadResult, UploadStatus


class CloudFamUploader(BaseUploader):
    """CloudFam file uploader using their API."""
    
    API_BASE_URL = "https://cloudfam.io/api.php"
    
    def __init__(self):
        """Initialize CloudFam uploader."""
        super().__init__("CloudFam")
        self._api_key: Optional[str] = None
    
    def set_credentials(self, credentials: Dict[str, Any]):
        """Set API key without validation."""
        self._api_key = credentials.get('api_key')
        self._credentials = credentials

    def authenticate(self, credentials: Dict[str, Any]) -> bool:
        """Authenticate with API key and validate.
        
        Args:
            credentials: Dict containing 'api_key'
            
        Returns:
            True if API key is valid
        """
        self.set_credentials(credentials)
        if not self._api_key:
            return False
        
        # Test API key by checking traffic quality
        try:
            response = requests.get(
                self.API_BASE_URL,
                params={'action': 'traffic_quality'},
                headers={'X-API-Key': self._api_key},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get('success', False)
            return False
        except Exception:
            return False
    
    def is_authenticated(self) -> bool:
        """Check if authenticated.
        
        Returns:
            True if API key is set
        """
        return self._api_key is not None
    
    def upload(self, file_path: str, progress_callback: Optional[Callable[[int], None]] = None, check_cancel: Optional[Callable[[], bool]] = None) -> UploadResult:
        """Upload file to CloudFam."""
        if not self.is_authenticated():
            return self._create_result(
                UploadStatus.FAILED,
                error_message="Not authenticated"
            )
        
        try:
            file_path_obj = Path(file_path)
            if not file_path_obj.exists():
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"File not found: {file_path}"
                )
            
            file_name = file_path_obj.name
            file_size = file_path_obj.stat().st_size
            
            if check_cancel and check_cancel():
                return self._create_result(UploadStatus.FAILED, error_message="Cancelled")

            # Step 1: Create upload URL
            if progress_callback:
                progress_callback(10)
            
            create_response = requests.get(
                self.API_BASE_URL,
                params={'action': 'create_upload_url'},
                headers={'X-API-Key': self._api_key},
                timeout=30
            )
            
            if create_response.status_code != 200:
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"Failed to create upload URL: {create_response.status_code}"
                )
            
            create_data = create_response.json()
            if not create_data.get('success'):
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message="Failed to create upload URL"
                )
            
            upload_url = create_data['uploadURL']
            upload_key = create_data['key']
            
            # Step 2: Upload file to presigned URL
            if progress_callback:
                progress_callback(10)
            
            from uploaders.base import ProgressFileReader
            # Use report_bytes=False for now since the callback signature hasn't changed yet,
            # but we ensured reading happens in chunks.
            with ProgressFileReader(file_path, progress_callback, 10, 80) as f:
                upload_response = requests.put(
                    upload_url,
                    data=f,
                    headers={'Content-Type': 'application/octet-stream'},
                    timeout=900
                )
            
            if upload_response.status_code not in [200, 201]:
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"File upload failed: {upload_response.status_code}"
                )
            
            # Step 3: Finalize upload
            finalize_response = requests.post(
                self.API_BASE_URL,
                params={'action': 'finalize_upload'},
                headers={'X-API-Key': self._api_key},
                json={
                    'key': upload_key,
                    'original_filename': file_name
                },
                timeout=30
            )
            
            if finalize_response.status_code != 201:
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"Failed to finalize upload: {finalize_response.status_code}"
                )
            
            finalize_data = finalize_response.json()
            if not finalize_data.get('success'):
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message="Failed to finalize upload"
                )
            
            download_link = finalize_data.get('download_link')
            
            if progress_callback:
                progress_callback(100)
            
            return self._create_result(
                UploadStatus.COMPLETED,
                download_link=download_link
            )
            
        except requests.exceptions.Timeout:
            return self._create_result(
                UploadStatus.FAILED,
                error_message="Upload timeout"
            )
        except Exception as e:
            return self._create_result(
                UploadStatus.FAILED,
                error_message=f"Upload error: {str(e)}"
            )
