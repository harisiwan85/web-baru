"""Mega4Upload uploader implementation."""
import os
import requests
import re
import urllib3
from typing import Callable, Optional, Dict, Any
from pathlib import Path
from bs4 import BeautifulSoup
from uploaders.base import BaseUploader, ProgressFileReader
from core.models import UploadResult, UploadStatus

# Suppress SSL warnings (Bypassing local cert issues in Laragon/Windows)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class Mega4UploadUploader(BaseUploader):
    """Mega4Upload file uploader using cookies and web scraping."""
    
    BASE_URL = "https://mega4upload.net"
    UPLOAD_URL = "https://mega4upload.net/?op=upload_form"
    
    def __init__(self):
        """Initialize Mega4Upload uploader."""
        super().__init__("Mega4Upload")
        self._cookies: Optional[Dict[str, str]] = None
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
    
    def set_credentials(self, credentials: Dict[str, Any]):
        """Set cookies without validation."""
        cookies = credentials.get('cookies', {})
        if not cookies:
            return
            
        self._cookies = cookies
        self._credentials = credentials
        
        self._session.cookies.clear()
        
        if isinstance(cookies, dict):
            for name, value in cookies.items():
                self._session.cookies.set(name, value)
        elif isinstance(cookies, list):
            for cookie_item in cookies:
                if isinstance(cookie_item, dict):
                    name = cookie_item.get('name') or cookie_item.get('Name')
                    value = cookie_item.get('value') or cookie_item.get('Value')
                    if name and value:
                        self._session.cookies.set(name, value)

    def authenticate(self, credentials: Dict[str, Any]) -> bool:
        """Authenticate using cookies and validate."""
        self.set_credentials(credentials)
        if not self._cookies:
            return False
            
        try:
            response = self._session.get(self.BASE_URL, timeout=15, verify=False)
            if response.status_code != 200:
                return False
            
            content = response.text.lower()
            # Standard XFS indicators (Matching Up-4ever logic)
            is_logged_in = "logout" in content or "my account" in content
            
            # Also check for account balance or space info which are member-only
            if not is_logged_in:
                is_logged_in = "balance" in content or "used space" in content
                
            return is_logged_in
        except Exception:
            return False
    
    def is_authenticated(self) -> bool:
        """Check if authenticated."""
        return self._cookies is not None
    
    def _get_upload_server(self) -> Optional[str]:
        """Fetch the current upload server URL (parsed from form)."""
        try:
            upload_page = self._session.get(self.UPLOAD_URL, timeout=20, verify=False)
            if upload_page.status_code != 200:
                upload_page = self._session.get(self.BASE_URL, timeout=20, verify=False)
                
            if upload_page.status_code == 200:
                soup = BeautifulSoup(upload_page.content, 'html.parser')
                form = soup.find('form', {'id': 'my-dropzone'}) or \
                       soup.find('form', {'id': 'uploadfile'}) or \
                       soup.find('form', {'id': 'fileupload'})
                
                if form and form.get('action') and form.get('action') != "#":
                    return form.get('action')
                
                # Fallback to script vars
                for var_name in ['srv_tmp_url', 'upload_url', 'upload_cgi']:
                    match = re.search(f'{var_name}\\s*=\\s*[\"\\\']([^\"\\\']+)[\"\\\']', upload_page.text)
                    if match:
                        return match.group(1)
        except Exception:
            pass
        return None

    def upload(self, file_path: str, progress_callback: Optional[Callable[[int], None]] = None, check_cancel: Optional[Callable[[], bool]] = None) -> UploadResult:
        """Upload file to Mega4Upload (Clone of Up-4ever logic)."""
        if not self.is_authenticated():
            try:
                if self._credentials:
                    self.authenticate(self._credentials)
                else:
                    return self._create_result(UploadStatus.FAILED, error_message="Not authenticated")
            except Exception:
                return self._create_result(UploadStatus.FAILED, error_message="Authentication failed")
        
        try:
            file_path_obj = Path(file_path)
            if not file_path_obj.exists():
                return self._create_result(UploadStatus.FAILED, error_message="File not found")
            
            file_name = file_path_obj.name
            
            if check_cancel and check_cancel():
                return self._create_result(UploadStatus.FAILED, error_message="Cancelled")

            if progress_callback:
                progress_callback(5)
            
            # 1. Get upload server (Standard XFS server detection)
            srv_url = self._get_upload_server()
            if not srv_url:
                srv_url = "https://s10.mega4down.com/cgi-bin" # Fallback
            
            if progress_callback:
                progress_callback(10)
            
            # 2. Get upload page to extract sess_id and other fields
            # Use verify=False here too
            upload_page = self._session.get(self.UPLOAD_URL, timeout=30, verify=False)
            if upload_page.status_code != 200:
                alt_url = f"{self.BASE_URL}/?op=upload_form"
                upload_page = self._session.get(alt_url, timeout=30, verify=False)
                
            if upload_page.status_code != 200:
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"Failed to access upload page (Status: {upload_page.status_code})"
                )
            
            # Parse upload form
            soup = BeautifulSoup(upload_page.content, 'html.parser')
            
            # Common form IDs/names for XFS
            form_identifiers = [
                {'id': 'my-dropzone'},  # New XFS / Dropzone
                {'id': 'uploadfile'},   # Common XFS
                {'id': 'fileupload'},
                {'name': 'file_upload'},
                {'id': 'upload_form'}
            ]
            
            upload_form = None
            for attr in form_identifiers:
                upload_form = soup.find('form', attr)
                if upload_form:
                    break
            
            if not upload_form:
                # Fallback: Find any form with a file input and POST method
                for form in soup.find_all('form'):
                    if form.get('method', '').upper() == 'POST' and form.find('input', {'type': 'file'}):
                        upload_form = form
                        break
            
            if not upload_form:
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message="Could not find upload form."
                )
            
            # Extract form fields and file field name
            form_data = {}
            file_field_name = "files[]" # Default for XFS
            for input_field in upload_form.find_all('input'):
                name = input_field.get('name')
                if not name: continue
                
                if input_field.get('type') == 'file':
                    file_field_name = name
                else:
                    form_data[name] = input_field.get('value', '')
            
            if progress_callback:
                progress_callback(20)
            
            # 3. Perform upload
            import random
            upload_id = "".join([str(random.randint(0, 9)) for _ in range(12)])
            
            upload_cgi = srv_url
            base_script = "upload.cgi"
            
            base_path = upload_cgi.split('?')[0]
            if not base_path.endswith('.cgi'):
                if upload_cgi.endswith('/'):
                    upload_cgi = base_path + base_script
                else:
                    upload_cgi = base_path + "/" + base_script
            
            # Add/Replace upload_id
            if '?' in upload_cgi:
                if 'upload_id=' in upload_cgi:
                    upload_cgi = re.sub(r'upload_id=\d+', f'upload_id={upload_id}', upload_cgi)
                else:
                    upload_cgi += f"&upload_id={upload_id}"
            else:
                upload_cgi += f"?upload_id={upload_id}"

            if not upload_cgi.startswith('http'):
                upload_cgi = "https:" + upload_cgi if upload_cgi.startswith('//') else upload_cgi

            # Find token in the whole page if not in form
            if 'token' not in form_data:
                token_match = re.search(r'name=[\"\\\']token[\"\\\']\s+value=[\"\\\']([^\"\\\']+)[\"\\\']', upload_page.text)
                if token_match:
                    form_data['token'] = token_match.group(1)
                else:
                    token_match = re.search(r'token\s*=\s*[\"\\\']([^\"\\\']+)[\"\\\']', upload_page.text)
                    if token_match:
                        form_data['token'] = token_match.group(1)

            # Ensure session info is passed
            xfss = self._session.cookies.get('xfss')
            if xfss:
                form_data['sess_id'] = xfss
                form_data['session_id'] = xfss

            # Update Referer and Origin
            headers = {
                'Referer': self.UPLOAD_URL,
                'Origin': self.BASE_URL,
                'User-Agent': self._session.headers.get('User-Agent')
            }

            # Use streaming upload helper for real-time progress
            files = {
                file_field_name: (file_name, open(file_path, 'rb'), 'application/octet-stream')
            }
            
            # Streaming upload with progress tracking and cancellation check
            upload_response = self._stream_upload(
                upload_cgi,
                files_dict=files,
                data_dict=form_data,
                headers=headers,
                progress_callback=progress_callback,
                start_progress=20,
                end_progress=90,
                verify=False,
                check_cancel=check_cancel
            )
            
            # Close file objects
            for f_info in files.values():
                f_info[1].close()
            
            if upload_response.status_code not in [200, 201, 302]:
                return self._create_result(
                    UploadStatus.FAILED,
                    error_message=f"Server rejected upload ({upload_response.status_code}). Info: {upload_response.text[:100]}"
                )
            
            # 4. Extract link or file code
            download_link = None
            response_text = upload_response.text
            
            # Try parsing JSON (often found at the end of response)
            try:
                # XFS sometimes has JSON at the last line
                lines = response_text.strip().split('\n')
                data = None
                for line in reversed(lines):
                    line = line.strip()
                    if (line.startswith('{') and line.endswith('}')) or (line.startswith('[') and line.endswith(']')):
                        import json
                        try:
                            data = json.loads(line)
                            break
                        except:
                            continue
                
                if not data:
                    data = upload_response.json()
                
                if isinstance(data, list) and len(data) > 0:
                    data = data[0]
                
                file_code = data.get('file_code') or data.get('code')
                if not file_code and 'url' in data:
                    download_link = data['url']
                elif file_code:
                    download_link = f"{self.BASE_URL}/{file_code}"
            except Exception:
                pass
            
            # Regex fallbacks (Multiple patterns for robustness)
            if not download_link:
                patterns = [
                    r'fn=([a-z0-9]+)',
                    r'\"file_code\":\"([a-z0-9]+)\"',
                    r'file_code\s*:\s*\'([a-z0-9]+)\''
                ]
                for p in patterns:
                    match = re.search(p, response_text, re.IGNORECASE)
                    if match:
                        download_link = f"{self.BASE_URL}/{match.group(1)}"
                        break
            
            if download_link:
                if progress_callback:
                    progress_callback(100)
                return self._create_result(UploadStatus.COMPLETED, download_link=download_link)
            
            return self._create_result(
                UploadStatus.FAILED,
                error_message=f"Upload finished but link not found. Body: {response_text[:100]}"
            )
            
        except Exception as e:
            return self._create_result(UploadStatus.FAILED, error_message=f"Upload error: {str(e)}")
