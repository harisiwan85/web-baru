from abc import ABC, abstractmethod
from typing import Callable, Optional, Dict, Any, Union
import os
import requests
from core.models import UploadResult, UploadStatus


class ProgressFileReader:
    """File-like wrapper that calls a callback on read to track progress."""
    def __init__(self, file_path: str, callback: Optional[Callable[[Union[int, float]], None]] = None, 
                 start_progress: int = 0, end_progress: int = 100, report_bytes: bool = False):
        self._f = open(file_path, 'rb')
        self._total_size = os.path.getsize(file_path)
        self._callback = callback
        self._read_bytes = 0
        self._start_progress = start_progress
        self._end_progress = end_progress
        self._report_bytes = report_bytes

    def read(self, size=-1):
        data = self._f.read(size)
        data_len = len(data)
        self._read_bytes += data_len
        
        if self._callback and self._total_size > 0:
            if self._report_bytes:
                # Reports (current_bytes, total_bytes)
                self._callback(self._read_bytes)
            else:
                progress_range = self._end_progress - self._start_progress
                progress = self._start_progress + (self._read_bytes / self._total_size * progress_range)
                self._callback(min(int(progress), self._end_progress))
        return data

    def __len__(self):
        return self._total_size

    def close(self):
        self._f.close()

    def __enter__(self):
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class BaseUploader(ABC):
    """Abstract base class for file uploaders."""
    
    def __init__(self, host_name: str):
        """Initialize uploader.
        
        Args:
            host_name: Name of the hosting service
        """
        self.host_name = host_name
        self._credentials: Optional[Dict[str, Any]] = None
        self._session = requests.Session()
    
    @abstractmethod
    def authenticate(self, credentials: Dict[str, Any]) -> bool:
        """Authenticate with the hosting service.
        
        Args:
            credentials: Authentication credentials (API key, cookies, etc.)
            
        Returns:
            True if authentication successful, False otherwise
        """
        pass
    
    @abstractmethod
    def set_credentials(self, credentials: Dict[str, Any]):
        """Set credentials without performing network validation.
        
        Args:
            credentials: Authentication credentials
        """
        pass
    
    @abstractmethod
    def is_authenticated(self) -> bool:
        """Check if currently authenticated.
        
        Returns:
            True if authenticated, False otherwise
        """
        pass
    
    @abstractmethod
    def upload(self, file_path: str, progress_callback: Optional[Callable[[int], None]] = None) -> UploadResult:
        """Upload a file to the hosting service.
        
        Args:
            file_path: Path to the file to upload
            progress_callback: Optional callback for progress updates (0-100)
            
        Returns:
            UploadResult containing download link and status
        """
        pass
    
    def _create_result(self, status: UploadStatus, download_link: Optional[str] = None, 
                      error_message: Optional[str] = None, file_id: Optional[str] = None) -> UploadResult:
        """Helper to create upload result."""
        return UploadResult(
            host_name=self.host_name,
            status=status,
            download_link=download_link,
            error_message=error_message,
            file_id=file_id
        )

    def _stream_upload(self, url: str, files_dict: Dict[str, Any], data_dict: Dict[str, str], 
                       headers: Dict[str, str], progress_callback: Optional[Callable[[int], None]] = None,
                       start_progress: int = 0, end_progress: int = 100, verify: bool = True,
                       check_cancel: Optional[Callable[[], bool]] = None) -> requests.Response:
        """Perform a streaming multipart upload with progress tracking."""
        return self._stream_upload_with_session(
            self._session, url, files_dict, data_dict, headers, 
            progress_callback, start_progress, end_progress, verify, check_cancel
        )
    
    def _stream_upload_with_session(self, session: requests.Session, url: str, files_dict: Dict[str, Any], 
                                    data_dict: Dict[str, str], headers: Dict[str, str], 
                                    progress_callback: Optional[Callable[[int], None]] = None,
                                    start_progress: int = 0, end_progress: int = 100, verify: bool = True,
                                    check_cancel: Optional[Callable[[], bool]] = None) -> requests.Response:
        """Perform a streaming multipart upload with progress tracking using a specific session."""
        from requests_toolbelt import MultipartEncoder, MultipartEncoderMonitor
        
        # Prepare fields for MultipartEncoder
        fields = data_dict.copy()
        for field_name, file_info in files_dict.items():
            # file_info is (filename, fileobj, content_type)
            fields[field_name] = file_info
            
        encoder = MultipartEncoder(fields=fields)
        
        def monitor_callback(monitor):
            if check_cancel and check_cancel():
                raise Exception("Upload Cancelled")
                
            if progress_callback:
                progress_range = end_progress - start_progress
                progress = start_progress + (monitor.bytes_read / monitor.len * progress_range)
                progress_callback(min(int(progress), end_progress))
        
        monitor = MultipartEncoderMonitor(encoder, monitor_callback)
        
        # Update headers with content-type from encoder
        headers['Content-Type'] = monitor.content_type
        
        return session.post(
            url, 
            data=monitor, 
            headers=headers, 
            timeout=3600, 
            verify=verify
        )
