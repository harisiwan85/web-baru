"""Test script to verify core functionality without GUI."""
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from core.storage import StorageManager
from core.upload_manager import UploadManager
from core.models import HostType, AuthMethod

def test_storage():
    """Test storage manager."""
    print("Testing Storage Manager...")
    storage = StorageManager()
    
    # Get host configs
    configs = storage.get_host_configs()
    print(f"✓ Loaded {len(configs)} host configurations")
    
    for config in configs:
        print(f"  - {config.name} ({config.host_type.value}): {'Enabled' if config.enabled else 'Disabled'}")
    
    return storage

def test_upload_manager(storage):
    """Test upload manager."""
    print("\nTesting Upload Manager...")
    manager = UploadManager(storage)
    
    # Check uploaders
    for host_name in ['CloudFam', 'Up-4ever']:
        uploader = manager.get_uploader(host_name)
        if uploader:
            print(f"✓ {host_name} uploader initialized")
            print(f"  - Authenticated: {uploader.is_authenticated()}")
        else:
            print(f"✗ {host_name} uploader not found")
    
    return manager

def main():
    """Run tests."""
    print("="*50)
    print("Multi-File Hosting Uploader - Core Test")
    print("="*50)
    
    try:
        storage = test_storage()
        manager = test_upload_manager(storage)
        
        print("\n" + "="*50)
        print("✓ All core components initialized successfully!")
        print("="*50)
        
        print("\nData directory:", storage.data_dir)
        print("Credentials file:", storage.credentials_file)
        print("Settings file:", storage.settings_file)
        
        return 0
    
    except Exception as e:
        print(f"\n✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
