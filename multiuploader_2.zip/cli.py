#!/usr/bin/env python3
"""Multi-File Hosting Uploader - CLI version (no GUI required).

Shares the same core logic and data folder as the desktop version:
  - core/storage.py        credentials & settings (data/ folder)
  - core/upload_manager.py upload orchestration
  - uploaders/             host implementations

Does not import PyQt5, so it runs on headless Linux servers.
"""
import argparse
import json
import os
import sys
import threading
from pathlib import Path

from core.models import UploadStatus
from core.storage import StorageManager
from core.upload_manager import UploadManager

NAME_WIDTH = 18
BAR_WIDTH = 24


def _enable_ansi():
    """Enable ANSI escape sequences on Windows consoles (no-op elsewhere)."""
    if os.name == 'nt':
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.GetStdHandle(-11)
            mode = ctypes.c_uint32(0)
            if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                kernel32.SetConsoleMode(handle, mode.value | 0x0004)
        except Exception:
            pass


def _human_size(num):
    num = float(num)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if num < 1024 or unit == 'TB':
            return f"{int(num)} {unit}" if unit == 'B' else f"{num:.1f} {unit}"
        num /= 1024


def _err(msg):
    # Flush stdout first so messages stay in order when output is piped
    # (stderr is unbuffered while piped stdout is block-buffered).
    sys.stdout.flush()
    print(f"Error: {msg}", file=sys.stderr)


class ProgressDisplay:
    """Per-host progress lines, redrawn in place on ANSI terminals.

    On non-tty output (piped/redirected) nothing is drawn during upload so
    logs stay clean; results are printed once at the end.
    """

    def __init__(self, hosts, use_ansi):
        self._lock = threading.Lock()
        self._use_ansi = use_ansi
        self._order = list(hosts)
        self._state = {h: {'pct': 0, 'done': False, 'ok': False, 'msg': ''}
                       for h in hosts}
        self._drawn = False

    def update(self, host, pct):
        with self._lock:
            st = self._state.get(host)
            if st and not st['done']:
                st['pct'] = int(pct)
            self._redraw()

    def finish(self, host, ok, msg=''):
        with self._lock:
            st = self._state.get(host)
            if st:
                st['done'] = True
                st['ok'] = ok
                st['msg'] = msg
                if ok:
                    st['pct'] = 100
            self._redraw()

    def _line(self, host):
        st = self._state[host]
        name = host[:NAME_WIDTH].ljust(NAME_WIDTH)
        if st['done']:
            tag = '[ OK ]' if st['ok'] else '[FAIL]'
            detail = st['msg'] or ('selesai' if st['ok'] else 'gagal')
            return f"  {name} {tag} {detail}"
        filled = int(BAR_WIDTH * st['pct'] / 100)
        bar = '#' * filled + '-' * (BAR_WIDTH - filled)
        return f"  {name} [{bar}] {st['pct']:3d}%"

    def _redraw(self):
        if not self._use_ansi:
            return
        lines = [self._line(h) for h in self._order]
        parts = []
        if self._drawn:
            parts.append(f"\x1b[{len(lines)}A")
        parts.append("\x1b[J")
        parts.append("\n".join(lines))
        parts.append("\n")
        sys.stdout.write("".join(parts))
        sys.stdout.flush()
        self._drawn = True


def _find_host(storage, name):
    wanted = name.strip().lower()
    for config in storage.get_host_configs():
        if config.name.lower() == wanted:
            return config
    return None


def _resolve_hosts(storage, wanted_list):
    """Map user-supplied host names (case-insensitive) to canonical names."""
    resolved, unknown = [], []
    for wanted in wanted_list:
        config = _find_host(storage, wanted)
        if config:
            if config.name not in resolved:
                resolved.append(config.name)
        else:
            unknown.append(wanted)
    return resolved, unknown


def _parse_cookies(text):
    """Accept JSON (dict or browser-export list) or a raw
    'name=value; name2=value2' cookie header string."""
    text = text.strip()
    try:
        data = json.loads(text)
    except ValueError:
        data = None
    if isinstance(data, (dict, list)) and data:
        return data

    cookies = {}
    for part in text.split(';'):
        if '=' in part:
            key, value = part.split('=', 1)
            if key.strip() and value.strip():
                cookies[key.strip()] = value.strip()
    return cookies


def cmd_hosts(args, storage, manager):
    manager.load_saved_credentials()
    configs = storage.get_host_configs()
    print(f"{'Nama':<20} {'Tipe':<20} {'Aktif':<7} Terautentikasi")
    print('-' * 62)
    for config in configs:
        active = 'ya' if config.enabled else 'tidak'
        auth = 'ya' if manager.is_host_authenticated(config.name) else 'tidak'
        print(f"{config.name:<20} {config.host_type.value:<20} {active:<7} {auth}")
    return 0


def _set_enabled(storage, name, enabled):
    configs = storage.get_host_configs()
    config = None
    for candidate in configs:
        if candidate.name.lower() == name.strip().lower():
            config = candidate
            break
    if not config:
        _err(f"Hosting tidak dikenal: {name}")
        return 2
    config.enabled = enabled
    storage.save_host_configs(configs)
    state = 'diaktifkan' if enabled else 'dinonaktifkan'
    print(f"{config.name} {state}.")
    return 0


def cmd_enable(args, storage, manager):
    return _set_enabled(storage, args.name, True)


def cmd_disable(args, storage, manager):
    return _set_enabled(storage, args.name, False)


def cmd_set(args, storage, manager):
    config = _find_host(storage, args.name)
    if not config:
        _err(f"Hosting tidak dikenal: {args.name}")
        return 2

    if args.clear:
        credentials = {}
    elif args.api_key:
        credentials = {'api_key': args.api_key}
    elif args.cookies_file:
        try:
            text = Path(args.cookies_file).read_text(encoding='utf-8')
        except OSError as exc:
            _err(f"Gagal membaca file cookies: {exc}")
            return 2
        credentials = {'cookies': _parse_cookies(text)}
    elif args.cookies is not None:
        credentials = {'cookies': _parse_cookies(args.cookies)}
    else:
        _err("Tentukan salah satu: --api-key, --cookies-file, --cookies, atau --clear")
        return 2

    manager.apply_host_credentials(config.name, credentials)
    print(f"Kredensial {config.name} tersimpan (data/credentials.json).")
    print(f"Verifikasi: python cli.py test \"{config.name}\"")
    return 0


def cmd_test(args, storage, manager):
    config = _find_host(storage, args.name)
    if not config:
        _err(f"Hosting tidak dikenal: {args.name}")
        return 2
    credentials = storage.get_host_credentials(config.name)
    if not credentials:
        _err(f"{config.name} belum punya kredensial. Simpan dulu, contoh: "
             f"python cli.py set \"{config.name}\" --api-key KEY")
        return 1

    print(f"Menguji {config.name} ...")
    if manager.authenticate_host(config.name, credentials):
        print(f"[ OK ] {config.name}: kredensial valid")
        return 0
    _err(f"[FAIL] {config.name}: kredensial tidak valid atau kadaluarsa")
    return 1


def cmd_upload(args, storage, manager):
    files = []
    for file_arg in args.files:
        path = Path(file_arg)
        if not path.exists():
            _err(f"File tidak ditemukan: {path}")
            return 2
        if path.is_dir():
            _err(f"'{path}' adalah direktori, hanya file yang didukung")
            return 2
        files.append(path)

    if args.hosts:
        wanted = [h for h in (s.strip() for s in args.hosts.split(',')) if h]
        enabled_hosts, unknown = _resolve_hosts(storage, wanted)
        if unknown:
            _err(f"Hosting tidak dikenal: {', '.join(unknown)}")
            return 2
    else:
        enabled_hosts = [c.name for c in storage.get_host_configs() if c.enabled]

    if not enabled_hosts:
        _err("Tidak ada hosting aktif. Aktifkan dengan: python cli.py enable <nama>")
        return 1

    manager.load_saved_credentials()

    active_hosts = []
    for host in enabled_hosts:
        if manager.is_host_authenticated(host):
            active_hosts.append(host)
        else:
            print(f"Dilewati (belum ada kredensial): {host}")
    if not active_hosts:
        _err("Tidak ada hosting aktif yang sudah dikonfigurasi. "
             "Cek dengan: python cli.py hosts")
        return 1

    if args.concurrency:
        if not 1 <= args.concurrency <= 10:
            _err("--concurrency harus antara 1-10")
            return 2
        settings = storage.load_settings()
        settings.setdefault('queue', {})['max_concurrent'] = args.concurrency
        storage.save_settings(settings)
        print(f"Konkurensi antrean: {args.concurrency}")

    use_ansi = sys.stdout.isatty() and not args.quiet and not args.json
    all_results = {}
    any_failed = False

    for path in files:
        print(f"\nMengunggah: {path.name} ({_human_size(path.stat().st_size)})")
        print(f"Tujuan    : {', '.join(active_hosts)}")

        display = ProgressDisplay(active_hosts, use_ansi)
        done_event = threading.Event()
        cancelled = threading.Event()

        job = manager.upload_file(
            str(path),
            active_hosts,
            progress_callback=display.update,
            completion_callback=lambda _job: done_event.set(),
            cancel_check_callback=lambda _host: cancelled.is_set(),
            host_completion_callback=lambda host, result: display.finish(
                host,
                result.status == UploadStatus.COMPLETED,
                result.download_link or result.error_message or ''
            ),
        )

        try:
            while not done_event.wait(0.2):
                # Fallback guard: the manager only fires the completion
                # callback from worker threads, so if every host fails
                # synchronously during queue start-up it never fires.
                if len(job.results) >= len(job.hosts):
                    break
        except KeyboardInterrupt:
            cancelled.set()
            manager.cancel_all()
            while not done_event.wait(0.2):
                if len(job.results) >= len(job.hosts):
                    break
            print("\nUpload dibatalkan oleh pengguna.")
            return 130

        links = []
        lines = []
        for host in active_hosts:
            result = job.results.get(host)
            if (result and result.status == UploadStatus.COMPLETED
                    and result.download_link):
                links.append(result.download_link)
                lines.append(f"  {host:<{NAME_WIDTH}} [ OK ] {result.download_link}")
            else:
                message = result.error_message if result else 'tidak ada hasil'
                lines.append(f"  {host:<{NAME_WIDTH}} [FAIL] {message}")
                any_failed = True

        all_results[path.name] = {
            host: result.to_dict() for host, result in job.results.items()
        }

        if not args.json:
            print(f"\nHasil untuk {path.name}:")
            print('\n'.join(lines))
            if links:
                print("\nLink download (satu per baris):")
                for link in links:
                    print(link)

    if args.output:
        Path(args.output).write_text(
            json.dumps(all_results, indent=2, ensure_ascii=False),
            encoding='utf-8'
        )
        print(f"\nHasil disimpan ke: {args.output}")

    if args.json:
        print(json.dumps(all_results, indent=2, ensure_ascii=False))

    return 1 if any_failed else 0


def build_parser():
    parser = argparse.ArgumentParser(
        prog='cli.py',
        description='Multi-File Hosting Uploader - versi CLI (tanpa GUI)'
    )
    sub = parser.add_subparsers(dest='command', metavar='PERINTAH')

    sp = sub.add_parser('hosts', help='Daftar hosting beserta statusnya')
    sp.set_defaults(func=cmd_hosts)

    sp = sub.add_parser('enable', help='Aktifkan hosting')
    sp.add_argument('name', help='Nama hosting, mis. "Up-4ever"')
    sp.set_defaults(func=cmd_enable)

    sp = sub.add_parser('disable', help='Nonaktifkan hosting')
    sp.add_argument('name')
    sp.set_defaults(func=cmd_disable)

    sp = sub.add_parser('set', help='Simpan kredensial hosting')
    sp.add_argument('name')
    sp.add_argument('--api-key',
                    help='API key (CloudFam, Up-4ever API, Mega4Upload API, Upfiles, send.now)')
    sp.add_argument('--cookies-file',
                    help='File cookies JSON (export browser) untuk hosting berbasis cookies')
    sp.add_argument('--cookies',
                    help='Cookies inline: JSON atau format "nama=nilai; nama2=nilai2"')
    sp.add_argument('--clear', action='store_true',
                    help='Hapus kredensial hosting ini')
    sp.set_defaults(func=cmd_set)

    sp = sub.add_parser('test', help='Uji kredensial hosting')
    sp.add_argument('name')
    sp.set_defaults(func=cmd_test)

    sp = sub.add_parser('upload', help='Upload file ke hosting aktif')
    sp.add_argument('files', nargs='+', help='File yang akan diunggah')
    sp.add_argument('--hosts',
                    help='Batasi hosting tujuan, pisah dengan koma (default: semua yang aktif)')
    sp.add_argument('--concurrency', type=int,
                    help='Jumlah upload paralel per file (1-10)')
    sp.add_argument('--json', action='store_true',
                    help='Cetak hasil sebagai JSON (cocok untuk scripting)')
    sp.add_argument('--output',
                    help='Simpan hasil lengkap ke file JSON')
    sp.add_argument('--quiet', action='store_true',
                    help='Tanpa progress bar')
    sp.set_defaults(func=cmd_upload)

    return parser


def main(argv=None):
    _enable_ansi()
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, 'func', None):
        parser.print_help()
        return 2

    storage = StorageManager()
    manager = UploadManager(storage)
    try:
        return args.func(args, storage, manager)
    except KeyboardInterrupt:
        print("\nDibatalkan.")
        return 130


if __name__ == '__main__':
    sys.exit(main())
