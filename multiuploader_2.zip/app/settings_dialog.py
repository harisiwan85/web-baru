"""Settings dialog for managing hosts and credentials."""
from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                             QPushButton, QCheckBox, QLineEdit, QTextEdit,
                             QGroupBox, QFormLayout, QMessageBox, QFileDialog,
                             QTabWidget, QWidget, QScrollArea, QTableWidget,
                             QTableWidgetItem, QHeaderView, QAbstractItemView,
                             QSpinBox, QComboBox)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QFont
from core.models import HostConfig, HostType, AuthMethod
import json


class HostTableWidget(QTableWidget):
    """Table widget for host settings with editable cells."""

    def __init__(self, storage_manager, upload_manager, parent=None):
        super().__init__(parent)
        self.storage = storage_manager
        self.upload_manager = upload_manager
        self.host_configs = []
        self._api_inputs = {}  # row -> input widget
        self._cookies_inputs = {}  # row -> input widget
        self._enabled_checks = {}  # row -> checkbox
        self.init_ui()

    def init_ui(self):
        """Initialize table UI."""
        self.setColumnCount(5)
        self.setHorizontalHeaderLabels(["No.", "Hosting", "API Key / Cookies", "Auth Type", "Aktif"])

        header = self.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)
        header.setSectionResizeMode(1, QHeaderView.Interactive)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        header.setSectionResizeMode(3, QHeaderView.Fixed)
        header.setSectionResizeMode(4, QHeaderView.Fixed)

        self.setColumnWidth(0, 50)
        self.setColumnWidth(3, 110)
        self.setColumnWidth(4, 60)

        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setAlternatingRowColors(True)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.verticalHeader().setVisible(False)
        self.setShowGrid(True)
        self.setStyleSheet("""
            QTableWidget {
                border: 1px solid #ddd;
                border-radius: 6px;
                background-color: white;
                gridline-color: #eee;
            }
            QTableWidget::item {
                padding: 6px;
            }
            QHeaderView::section {
                background-color: #f8f9fa;
                padding: 8px;
                border: none;
                border-bottom: 2px solid #eee;
                font-weight: bold;
                color: #555;
            }
        """)

    def load_hosts(self):
        """Load host configurations into table."""
        self.host_configs = self.storage.get_host_configs()
        self.setRowCount(len(self.host_configs))

        self._api_inputs.clear()
        self._cookies_inputs.clear()
        self._enabled_checks.clear()

        for row, config in enumerate(self.host_configs):
            # No.
            no_item = QTableWidgetItem(str(row + 1))
            no_item.setTextAlignment(Qt.AlignCenter)
            no_item.setFlags(no_item.flags() & ~Qt.ItemIsEditable)
            self.setItem(row, 0, no_item)

            # Host Name
            name_item = QTableWidgetItem(config.name)
            name_item.setFlags(name_item.flags() & ~Qt.ItemIsEditable)
            self.setItem(row, 1, name_item)

            # API Key / Cookies input
            credentials = self.storage.get_host_credentials(config.name) or {}
            auth_method = config.auth_method

            if auth_method == AuthMethod.API_KEY:
                api_input = QLineEdit()
                api_input.setPlaceholderText(f"API Key untuk {config.name}")
                api_input.setText(credentials.get('api_key', ''))
                api_input.setObjectName(f"api_{config.name}")
                self.setCellWidget(row, 2, api_input)
                self._api_inputs[row] = api_input

                # Auth type label
                auth_label = QLabel("API Key")
                auth_label.setAlignment(Qt.AlignCenter)
                auth_label.setStyleSheet("color: #666; font-size: 11px;")
                self.setCellWidget(row, 3, auth_label)

            elif auth_method == AuthMethod.COOKIES:
                cookies_input = QLineEdit()
                cookies_input.setPlaceholderText(f"Cookies JSON untuk {config.name}")
                saved_cookies = credentials.get('cookies', {})
                if saved_cookies:
                    cookies_input.setText(json.dumps(saved_cookies, separators=(',', ':')))
                cookies_input.setObjectName(f"cookies_{config.name}")
                self.setCellWidget(row, 2, cookies_input)
                self._cookies_inputs[row] = cookies_input

                # Auth type label
                auth_label = QLabel("Cookies")
                auth_label.setAlignment(Qt.AlignCenter)
                auth_label.setStyleSheet("color: #666; font-size: 11px;")
                self.setCellWidget(row, 3, auth_label)

            # Enabled checkbox
            enabled_cb = QCheckBox()
            enabled_cb.setChecked(config.enabled)
            enabled_cb.setObjectName(f"enabled_{config.name}")
            # Center the checkbox
            cb_widget = QWidget()
            cb_layout = QHBoxLayout(cb_widget)
            cb_layout.addWidget(enabled_cb)
            cb_layout.setAlignment(Qt.AlignCenter)
            cb_layout.setContentsMargins(0, 0, 0, 0)
            self.setCellWidget(row, 4, cb_widget)
            self._enabled_checks[row] = enabled_cb

        self.resizeRowsToContents()

    def get_host_settings(self):
        """Extract settings from table widgets."""
        settings = []
        for row, config in enumerate(self.host_configs):
            enabled = self._enabled_checks.get(row)
            enabled_val = enabled.isChecked() if enabled else config.enabled

            credentials = {}
            if config.auth_method == AuthMethod.API_KEY:
                api_input = self._api_inputs.get(row)
                if api_input:
                    api_key = api_input.text().strip()
                    if api_key:
                        credentials['api_key'] = api_key
            elif config.auth_method == AuthMethod.COOKIES:
                cookies_input = self._cookies_inputs.get(row)
                if cookies_input:
                    cookies_text = cookies_input.text().strip()
                    if cookies_text:
                        try:
                            cookies = json.loads(cookies_text)
                            credentials['cookies'] = cookies
                        except json.JSONDecodeError:
                            raise ValueError(f"Invalid JSON cookies for {config.name}")

            settings.append({
                'name': config.name,
                'host_type': config.host_type.value,
                'enabled': enabled_val,
                'auth_method': config.auth_method.value,
                'credentials': credentials
            })
        return settings


class QueueSettingsWidget(QWidget):
    """Widget for queue/concurrency settings."""

    def __init__(self, storage_manager, parent=None):
        super().__init__(parent)
        self.storage = storage_manager
        self.init_ui()
        self.load_settings()

    def init_ui(self):
        """Initialize queue settings UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        # Title
        title = QLabel("⚙ Pengaturan Antrian Upload")
        title.setFont(QFont("Segoe UI", 14, QFont.Bold))
        layout.addWidget(title)

        layout.addSpacing(20)

        # Concurrent uploads group
        group = QGroupBox("Jumlah Upload Bersamaan (Concurrency)")
        group_layout = QFormLayout(group)

        self.concurrent_spin = QSpinBox()
        self.concurrent_spin.setRange(1, 10)
        self.concurrent_spin.setValue(2)
        self.concurrent_spin.setToolTip("Maksimal jumlah hosting yang upload bersamaan. Hosting siswa akan antri.")
        group_layout.addRow("Maksimal concurrent upload:", self.concurrent_spin)

        info_label = QLabel(
            "Contoh: Jika 4 hosting aktif dan concurrent = 2,\n"
            "maka 2 hosting upload duluan, sisanya antri.\n"
            "Saat satu selesai, hosting berikutnya otomatis mulai."
        )
        info_label.setStyleSheet("color: #666; font-size: 11px;")
        info_label.setWordWrap(True)
        group_layout.addRow("", info_label)

        layout.addWidget(group)

        # Queue behavior group
        behavior_group = QGroupBox("Perilaku Antrian")
        behavior_layout = QFormLayout(behavior_group)

        self.auto_start_cb = QCheckBox("Mulai otomatis saat antrian dikosongkan")
        self.auto_start_cb.setChecked(True)
        behavior_layout.addRow("", self.auto_start_cb)

        self.pause_on_error_cb = QCheckBox("Pause antrian jika ada error (butuh konfirmasi lanjut)")
        self.pause_on_error_cb.setChecked(False)
        behavior_layout.addRow("", self.pause_on_error_cb)

        layout.addWidget(behavior_group)

        layout.addStretch()

        # Save button
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        self.save_btn = QPushButton("Simpan Pengaturan Antrian")
        self.save_btn.clicked.connect(self.save_settings)
        self.save_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 10px 25px;
                border-radius: 6px;
                font-weight: bold;
                font-size: 13px;
            }
            QPushButton:hover { background-color: #45a049; }
        """)
        btn_layout.addWidget(self.save_btn)
        layout.addLayout(btn_layout)

    def load_settings(self):
        """Load queue settings from storage."""
        settings = self.storage.load_settings()
        queue_settings = settings.get('queue', {})
        self.concurrent_spin.setValue(queue_settings.get('max_concurrent', 2))
        self.auto_start_cb.setChecked(queue_settings.get('auto_start', True))
        self.pause_on_error_cb.setChecked(queue_settings.get('pause_on_error', False))

    def save_settings(self):
        """Save queue settings."""
        settings = self.storage.load_settings()
        settings['queue'] = {
            'max_concurrent': self.concurrent_spin.value(),
            'auto_start': self.auto_start_cb.isChecked(),
            'pause_on_error': self.pause_on_error_cb.isChecked()
        }
        self.storage.save_settings(settings)
        QMessageBox.information(self, "Berhasil", "Pengaturan antrian disimpan!")


class SettingsDialog(QDialog):
    """Settings dialog with host table and queue settings tabs."""

    def __init__(self, storage_manager, upload_manager, parent=None):
        super().__init__(parent)
        self.storage = storage_manager
        self.upload_manager = upload_manager

        self.init_ui()
        self.load_all_settings()

    def init_ui(self):
        """Initialize UI."""
        self.setWindowTitle("Pengaturan")
        self.setMinimumSize(850, 600)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)

        # Tab widget
        tabs = QTabWidget()

        # Tab 1: Host Settings (Table)
        self.host_table = HostTableWidget(self.storage, self.upload_manager)
        host_tab = QWidget()
        host_layout = QVBoxLayout(host_tab)
        host_layout.setContentsMargins(10, 10, 10, 10)

        # Toolbar for host tab
        toolbar = QHBoxLayout()
        toolbar.addWidget(QLabel("📋 Daftar Hosting File"))
        toolbar.addStretch()

        self.test_all_btn = QPushButton("🔍 Test Semua Koneksi")
        self.test_all_btn.clicked.connect(self.test_all_connections)
        self.test_all_btn.setStyleSheet("""
            QPushButton { background-color: #2196F3; color: white; border: none;
                padding: 6px 15px; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #1976D2; }
        """)
        toolbar.addWidget(self.test_all_btn)

        self.import_all_btn = QPushButton("📥 Import Semua Cookies")
        self.import_all_btn.clicked.connect(self.import_all_cookies)
        self.import_all_btn.setStyleSheet("""
            QPushButton { background-color: #FF9800; color: white; border: none;
                padding: 6px 15px; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #F57C00; }
        """)
        toolbar.addWidget(self.import_all_btn)

        host_layout.addLayout(toolbar)
        host_layout.addWidget(self.host_table)

        # Buttons for host tab
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        self.save_hosts_btn = QPushButton("💾 Simpan Semua Hosting")
        self.save_hosts_btn.clicked.connect(self.save_host_settings)
        self.save_hosts_btn.setStyleSheet("""
            QPushButton { background-color: #4CAF50; color: white; border: none;
                padding: 10px 25px; border-radius: 6px; font-weight: bold; font-size: 13px; }
            QPushButton:hover { background-color: #45a049; }
        """)
        btn_layout.addWidget(self.save_hosts_btn)
        host_layout.addLayout(btn_layout)

        tabs.addTab(host_tab, "🌐 Hosting Settings")

        # Tab 2: Queue Settings
        self.queue_widget = QueueSettingsWidget(self.storage)
        tabs.addTab(self.queue_widget, "📋 Antrian Upload")

        layout.addWidget(tabs)

        # Close button
        close_layout = QHBoxLayout()
        close_layout.addStretch()
        close_btn = QPushButton("Tutup")
        close_btn.clicked.connect(self.accept)
        close_btn.setStyleSheet("""
            QPushButton { background-color: #f44336; color: white; border: none;
                padding: 8px 20px; border-radius: 5px; font-weight: bold; }
            QPushButton:hover { background-color: #da190b; }
        """)
        close_layout.addWidget(close_btn)
        layout.addLayout(close_layout)

    def load_all_settings(self):
        """Load all settings into UI."""
        self.host_table.load_hosts()
        self.queue_widget.load_settings()

    def save_host_settings(self):
        """Save host settings from table."""
        try:
            settings = self.host_table.get_host_settings()

            # Update storage
            self.storage.save_host_configs([
                HostConfig.from_dict(s) for s in settings
            ])

            # Apply credentials to upload managers
            for s in settings:
                if s['credentials']:
                    self.upload_manager.apply_host_credentials(s['name'], s['credentials'])

            QMessageBox.information(self, "Berhasil", "Semua pengaturan hosting disimpan!")
        except ValueError as e:
            QMessageBox.warning(self, "Error", str(e))
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Gagal menyimpan: {str(e)}")

    def test_all_connections(self):
        """Test authentication for all hosts that have credentials."""
        from PyQt5.QtWidgets import QProgressDialog, QApplication
        from PyQt5.QtCore import Qt

        hosts_to_test = []
        for row, config in enumerate(self.host_table.host_configs):
            credentials = {}
            if config.auth_method == AuthMethod.API_KEY:
                api_input = self.host_table._api_inputs.get(row)
                if api_input and api_input.text().strip():
                    credentials['api_key'] = api_input.text().strip()
            elif config.auth_method == AuthMethod.COOKIES:
                cookies_input = self.host_table._cookies_inputs.get(row)
                if cookies_input and cookies_input.text().strip():
                    try:
                        cookies = json.loads(cookies_input.text().strip())
                        credentials['cookies'] = cookies
                    except json.JSONDecodeError:
                        continue

            if credentials:
                hosts_to_test.append((config.name, credentials))

        if not hosts_to_test:
            QMessageBox.information(self, "Info", "Tidak ada kredensial untuk ditest.")
            return

        progress = QProgressDialog("Testing koneksi...", "Batal", 0, len(hosts_to_test), self)
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)

        results = []
        for i, (host_name, credentials) in enumerate(hosts_to_test):
            if progress.wasCanceled():
                break
            progress.setLabelText(f"Testing {host_name}...")
            progress.setValue(i)
            QApplication.processEvents()

            success = self.upload_manager.authenticate_host(host_name, credentials)
            results.append((host_name, success))

        progress.setValue(len(hosts_to_test))

        # Show results
        msg_lines = []
        for host_name, success in results:
            status = "✅ Berhasil" if success else "❌ Gagal"
            msg_lines.append(f"{host_name}: {status}")

        QMessageBox.information(self, "Hasil Test Koneksi", "\n".join(msg_lines))

    def import_all_cookies(self):
        """Import cookies for all cookie-based hosts."""
        for row, config in enumerate(self.host_table.host_configs):
            if config.auth_method == AuthMethod.COOKIES:
                file_path, _ = QFileDialog.getOpenFileName(
                    self,
                    f"Import Cookies untuk {config.name}",
                    "",
                    "JSON Files (*.json);;Text Files (*.txt);;All Files (*.*)"
                )
                if file_path:
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            cookies = json.load(f)
                        cookies_input = self.host_table._cookies_inputs.get(row)
                        if cookies_input:
                            cookies_input.setText(json.dumps(cookies, separators=(',', ':')))
                    except json.JSONDecodeError:
                        QMessageBox.warning(self, "Error", f"File JSON tidak valid untuk {config.name}")
                        return
                    except Exception as e:
                        QMessageBox.critical(self, "Error", f"Gagal import: {str(e)}")
                        return
        QMessageBox.information(self, "Berhasil", "Cookies diimport untuk hosting yang dipilih.")

    def get_queue_settings(self):
        """Get current queue settings."""
        settings = self.storage.load_settings()
        return settings.get('queue', {
            'max_concurrent': 2,
            'auto_start': True,
            'pause_on_error': False
        })