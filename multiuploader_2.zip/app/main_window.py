from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QPushButton, QLabel, QFileDialog, QScrollArea,
                             QFrame, QSplitter, QMessageBox, QTableWidget,
                             QTableWidgetItem, QHeaderView, QProgressBar,
                             QAction, QMenu, QMenuBar, QSizePolicy)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QUrl
from PyQt5.QtGui import QDragEnterEvent, QDropEvent, QFont, QDesktopServices, QIcon
from pathlib import Path
import time
import os
import sys
import ctypes
from core.storage import StorageManager
from core.upload_manager import UploadManager
from core.models import UploadJob, UploadStatus
from app.settings_dialog import SettingsDialog


PROGRESS_BAR_STYLE = """
    QProgressBar {
        border: 1px solid #ddd;
        border-radius: 6px;
        text-align: center;
        background: #fdfdfd;
        font-weight: bold;
    }
    QProgressBar::chunk {
        background-color: #2196F3;
        border-radius: 5px;
    }
"""


class UploadThread(QThread):
    """Thread for handling file uploads."""
    
    # file_name, host_name, progress_percent, bytes_read
    progress_updated = pyqtSignal(str, str, int, int)
    host_upload_completed = pyqtSignal(str, str, object) # file_name, host_name, UploadResult
    upload_completed = pyqtSignal(str, object)  # file_name, UploadJob (Still used for final cleanup if needed)
    
    def __init__(self, upload_manager, file_path, enabled_hosts):
        super().__init__()
        self.upload_manager = upload_manager
        self.file_path = file_path
        self.enabled_hosts = enabled_hosts
        self.file_name = Path(file_path).name
        self.file_size = Path(file_path).stat().st_size
        self._cancelled_hosts = set()
        self._paused = False
        
    def cancel_host(self, host_name):
        """Cancel upload for a specific host."""
        self._cancelled_hosts.add(host_name)
        
    def pause(self):
        """Pause upload."""
        self._paused = True
        
    def resume(self):
        """Resume upload."""
        self._paused = False

    def run(self):
        """Run upload in thread."""
        def progress_callback(host_name, progress):
            # Calculate bytes read based on percent
            bytes_read = int(self.file_size * (progress / 100.0))
            self.progress_updated.emit(self.file_name, host_name, progress, bytes_read)
        
        def host_completion_callback(host_name, result):
            self.host_upload_completed.emit(self.file_name, host_name, result)

        def completion_callback(job):
            self.upload_completed.emit(self.file_name, job)
            
        def cancel_check_callback(host_name):
            # Check pause state first (simple blocking implementation)
            while self._paused:
                if host_name in self._cancelled_hosts:
                    return True
                self.msleep(100) # Sleep 100ms
                
            return host_name in self._cancelled_hosts
        
        self.upload_manager.upload_file(
            self.file_path,
            self.enabled_hosts,
            progress_callback,
            completion_callback,
            cancel_check_callback,
            host_completion_callback # Pass the new callback
        )


class MainWindow(QMainWindow):
    """Main application window."""
    
    def __init__(self):
        super().__init__()
        self.storage = StorageManager()
        self.upload_manager = UploadManager(self.storage)
        self.upload_threads = []
        self.upload_rows = {}  # (file_name, host_name) -> row_index
        self.upload_start_times = {} # (file_name, host_name) -> start_time
        self.file_sizes = {} # file_name -> size_str
        self._initial_bytes = {} # (file_name, host_name) -> first_reported_bytes
        
        self.init_ui()
        self.load_credentials()
    
    def format_size(self, size):
        """Format size in bytes to human readable string."""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.2f} {unit}"
            size /= 1024.0
        return f"{size:.2f} PB"

    def _make_progress_bar(self, value=0):
        """Create a progress bar that fills the full row height."""
        bar = QProgressBar()
        bar.setRange(0, 100)
        bar.setValue(value)
        bar.setMinimumHeight(14)
        bar.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        bar.setStyleSheet(PROGRESS_BAR_STYLE)
        return bar

    def init_ui(self):
        """Initialize user interface."""
        self.setWindowTitle("Multi-File Hosting Uploader")
        self.setMinimumSize(1200, 700)
        
        # Set Application Icon
        if hasattr(sys, '_MEIPASS'):
            icon_path = os.path.join(sys._MEIPASS, 'icon.ico')
        else:
            icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'icon.ico')
            if not os.path.exists(icon_path):
                icon_path = 'icon.ico'
            
        if os.path.exists(icon_path):
            app_icon = QIcon(icon_path)
            self.setWindowIcon(app_icon)
            
            # Windows taskbar icon fix
            if sys.platform == 'win32':
                myappid = 'webstudio.multiuploader.v1'
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
        
        # Menu Bar
        self.init_menubar()
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        
        # Header
        header_layout = QHBoxLayout()
        
        title_label = QLabel("🚀 Multi-File Hosting Uploader")
        title_font = QFont()
        title_font.setPointSize(18)
        title_font.setBold(True)
        title_label.setFont(title_font)
        header_layout.addWidget(title_label)
        
        header_layout.addStretch()
        
        # Settings button (Blue)
        self.settings_btn = QPushButton("⚙ Settings")
        self.settings_btn.clicked.connect(self.show_settings)
        self.settings_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 10px 25px;
                border-radius: 6px;
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        header_layout.addWidget(self.settings_btn)
        
        main_layout.addLayout(header_layout)
        
        # Content Layout (Table keeps full width)
        content_layout = QVBoxLayout()
        
        # Enable drag and drop for the whole window
        self.setAcceptDrops(True)
        
        # Control Buttons
        controls_layout = QHBoxLayout()
        
        self.browse_btn = QPushButton("📂 Add Files")
        self.browse_btn.clicked.connect(self.browse_files)
        
        self.pause_btn = QPushButton("⏸ Pause")
        self.pause_btn.clicked.connect(self.pause_selected)
        
        self.stop_btn = QPushButton("⏹ Stop")
        self.stop_btn.clicked.connect(self.stop_selected)
        
        self.reupload_btn = QPushButton("🔄 Re-upload")
        self.reupload_btn.clicked.connect(self.reupload_selected)
        
        self.copy_all_btn = QPushButton("📋 Copy All Links")
        self.copy_all_btn.clicked.connect(self.copy_all_links)
        
        # Style all buttons uniformly
        buttons = [
            (self.browse_btn, "#4CAF50", "white"),  # Green for Add
            (self.pause_btn, "#f0f0f0", "#333"),
            (self.stop_btn, "#f0f0f0", "#333"),
            (self.reupload_btn, "#f0f0f0", "#333"),
            (self.copy_all_btn, "#2196F3", "white")  # Blue for Copy
        ]
        
        for btn, bg_color, text_color in buttons:
            border = "1px solid #ccc" if bg_color == "#f0f0f0" else "none"
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {bg_color};
                    color: {text_color};
                    border: {border};
                    padding: 8px 15px;
                    border-radius: 4px;
                    font-weight: bold;
                    font-size: 13px;
                }}
                QPushButton:hover {{
                    opacity: 0.9;
                }}
            """)
            controls_layout.addWidget(btn)
            
        controls_layout.addStretch()
        content_layout.addLayout(controls_layout)
        
        # Table
        self.upload_table = QTableWidget()
        self.upload_table.setColumnCount(7)
        self.upload_table.setHorizontalHeaderLabels([
            "File Name", "Size / Progress", "Host", "Status", "Speed", "Progress Bar", "Download Link"
        ])
        
        header = self.upload_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch) # File Name
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents) # Size
        header.setSectionResizeMode(2, QHeaderView.Interactive) # Host
        header.setSectionResizeMode(3, QHeaderView.Interactive) # Status
        header.setSectionResizeMode(4, QHeaderView.Interactive) # Speed
        header.setSectionResizeMode(5, QHeaderView.Stretch) # Progress Bar
        header.setSectionResizeMode(6, QHeaderView.Stretch) # Download Link
        
        self.upload_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.upload_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.upload_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.upload_table.setWordWrap(False) # Keep text (e.g. file names) on one line
        self.upload_table.verticalHeader().setVisible(False)
        self.upload_table.setAlternatingRowColors(True)
        self.upload_table.setAcceptDrops(True) # Ensure table accepts drops too
        self.upload_table.dragEnterEvent = self.drag_enter_event
        self.upload_table.dragMoveEvent = self.drag_enter_event # Handle move as enter
        self.upload_table.dropEvent = self.drop_event
        self.upload_table.itemSelectionChanged.connect(self.on_selection_changed)
        self.upload_table.setStyleSheet("""
            QTableWidget {
                border: 1px solid #ddd;
                border-radius: 8px;
                background-color: white;
                gridline-color: #eee;
            }
            QTableWidget::item {
                padding: 4px;
            }
            QHeaderView::section {
                background-color: #f8f9fa;
                padding: 8px;
                border: none;
                border-bottom: 2px solid #eee;
                font-weight: bold;
                color: #555;
            }
        """)
        
        content_layout.addWidget(self.upload_table)
        main_layout.addLayout(content_layout)
        
        # Status Bar with Footer
        self.init_statusbar()
    
    def init_menubar(self):
        """Initialize menu bar."""
        menubar = self.menuBar()
        
        # File Menu
        file_menu = menubar.addMenu("&File")
        
        open_action = QAction("📂 &Open Files...", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self.browse_files)
        file_menu.addAction(open_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("🚪 E&xit", self)
        exit_action.setShortcut("Alt+F4")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Tools Menu
        tools_menu = menubar.addMenu("&Tools")
        
        settings_action = QAction("⚙ &Settings", self)
        settings_action.triggered.connect(self.show_settings)
        tools_menu.addAction(settings_action)
        
        # Help Menu
        help_menu = menubar.addMenu("&Help")
        
        about_action = QAction("ℹ &About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def init_statusbar(self):
        """Initialize status bar with custom footer."""
        status_bar = self.statusBar()
        
        # Left status
        self.status_label = QLabel("Ready")
        status_bar.addWidget(self.status_label)
        
        # Right footer
        footer_widget = QWidget()
        footer_layout = QHBoxLayout(footer_widget)
        footer_layout.setContentsMargins(0, 0, 10, 0)
        
        footer_text = QLabel("Dibuat dengan ♥️ oleh ")
        footer_link = QLabel('<a href="https://webstudio.my.id" style="color: #2196F3; text-decoration: none;">Webstudio</a>')
        footer_link.setOpenExternalLinks(True)
        
        footer_layout.addWidget(footer_text)
        footer_layout.addWidget(footer_link)
        
        status_bar.addPermanentWidget(footer_widget)

    def keyPressEvent(self, event):
        """Handle keyboard shortcuts."""
        # Ctrl+A to select all
        if event.key() == Qt.Key_A and event.modifiers() == Qt.ControlModifier:
            self.upload_table.selectAll()
        
        # Delete or Backspace to remove items
        elif event.key() == Qt.Key_Delete or event.key() == Qt.Key_Backspace:
            self.remove_selected_rows()
            
        super().keyPressEvent(event)

    def remove_selected_rows(self):
        """Remove selected rows from the table."""
        selected_ranges = self.upload_table.selectedRanges()
        if not selected_ranges:
            return
            
        # Get all row indices to remove
        rows_to_remove = set()
        for r in selected_ranges:
            for row in range(r.topRow(), r.bottomRow() + 1):
                rows_to_remove.add(row)
        
        # Sort in descending order to avoid index shift
        sorted_rows = sorted(list(rows_to_remove), reverse=True)
        
        for row in sorted_rows:
            file_name = self.upload_table.item(row, 0).text()
            host_name = self.upload_table.item(row, 2).text()
            
            # Clean up internal mappings
            key = (file_name, host_name)
            if key in self.upload_rows:
                del self.upload_rows[key]
            if key in self.upload_start_times:
                del self.upload_start_times[key]
            if key in self._initial_bytes:
                del self._initial_bytes[key]
                
            self.upload_table.removeRow(row)
            
        # Update row indices for remaining items
        self.upload_rows = {}
        for row in range(self.upload_table.rowCount()):
            f = self.upload_table.item(row, 0).text()
            h = self.upload_table.item(row, 2).text()
            self.upload_rows[(f, h)] = row

    def show_about(self):
        """Show about dialog."""
        QMessageBox.about(self, "About", 
            "<h3>Multi-File Hosting Uploader</h3>"
            "<p>A powerful tool to upload files to multiple hosts simultaneously.</p>"
            "<p>Developed by <b>Webstudio</b></p>"
            '<p><a href="https://webstudio.my.id">https://webstudio.my.id</a></p>')
    
    def load_credentials(self):
        """Load saved credentials."""
        self.upload_manager.load_saved_credentials()
    
    def show_settings(self):
        """Show settings dialog."""
        dialog = SettingsDialog(self.storage, self.upload_manager, self)
        dialog.exec()
    
    def browse_files(self):
        """Browse for files to upload."""
        last_dir = self.storage.get_last_upload_dir()
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Select Files to Upload",
            last_dir,
            "All Files (*.*)"
        )
        
        if files:
            # Save last directory
            self.storage.save_last_upload_dir(str(Path(files[0]).parent))
            
            for file_path in files:
                self.start_upload(file_path)
    
    def drag_enter_event(self, event: QDragEnterEvent):
        """Handle drag enter event."""
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
    
    def drop_event(self, event: QDropEvent):
        """Handle drop event."""
        files = [url.toLocalFile() for url in event.mimeData().urls()]
        
        if files:
            # Save last directory
            self.storage.save_last_upload_dir(str(Path(files[0]).parent))
            for file_path in files:
                if Path(file_path).is_file():
                    self.start_upload(file_path)
    
    def on_selection_changed(self):
        """Handle selection change to automatically copy all selected download links."""
        selected_ranges = self.upload_table.selectedRanges()
        if not selected_ranges:
            return
            
        links = []
        rows = set()
        for r in selected_ranges:
            for row in range(r.topRow(), r.bottomRow() + 1):
                rows.add(row)
        
        for row in sorted(list(rows)):
            link_item = self.upload_table.item(row, 6)
            if link_item and link_item.text():
                links.append(link_item.text())
        
        if links:
            from PyQt5.QtWidgets import QApplication
            clipboard = QApplication.clipboard()
            clipboard.setText("\n".join(links))
            
            # Show brief status feedback
            count = len(links)
            msg = f"Copied {count} link{'s' if count > 1 else ''} to clipboard"
            self.statusBar().showMessage(msg, 2000)

    def copy_all_links(self):
        """Copy all available download links to clipboard."""
        links = []
        for row in range(self.upload_table.rowCount()):
            item = self.upload_table.item(row, 6)
            if item and item.text():
                links.append(item.text())
        
        if links:
            from PyQt5.QtWidgets import QApplication
            clipboard = QApplication.clipboard()
            clipboard.setText("\n".join(links))
            QMessageBox.information(self, "Copied", f"All {len(links)} links copied to clipboard!")
        else:
            QMessageBox.warning(self, "No Links", "No download links available to copy.")

    def start_upload(self, file_path: str):
        """Start uploading a file."""
        enabled_hosts = self.upload_manager.get_enabled_hosts()
        
        if not enabled_hosts:
            QMessageBox.warning(self, "No Hosts Enabled", "Please enable at least one hosting service in Settings.")
            return
        
        # Check authentication
        unauthenticated = [h for h in enabled_hosts if not self.upload_manager.is_host_authenticated(h)]
        if unauthenticated:
            QMessageBox.warning(self, "Authentication Required", f"Please authenticate with: {', '.join(unauthenticated)}\nGo to Settings.")
            return
        
        file_path_obj = Path(file_path)
        file_name = file_path_obj.name
        file_size = file_path_obj.stat().st_size
        size_str = self.format_size(file_size)
        self.file_sizes[file_name] = file_size
        
        # Add rows for each host
        for host in enabled_hosts:
            row = self.upload_table.rowCount()
            self.upload_table.insertRow(row)
            
            self.upload_table.setItem(row, 0, QTableWidgetItem(file_name))
            # Column 1: Size / Progress detail
            self.upload_table.setItem(row, 1, QTableWidgetItem(size_str))
            self.upload_table.setItem(row, 2, QTableWidgetItem(host))
            self.upload_table.setItem(row, 3, QTableWidgetItem("Pending"))
            self.upload_table.setItem(row, 4, QTableWidgetItem("0 KB/s"))
            
            # Store file path in the file name item for re-uploading
            self.upload_table.item(row, 0).setData(Qt.UserRole, file_path)
            
            progress_bar = self._make_progress_bar(0)
            self.upload_table.setCellWidget(row, 5, progress_bar)
            self.upload_table.setRowHeight(row, 26)
            
            # Column 6: Download Link
            self.upload_table.setItem(row, 6, QTableWidgetItem(""))
            
            self.upload_rows[(file_name, host)] = row
            self.upload_start_times[(file_name, host)] = time.time()
        
        # Create and start upload thread
        thread = UploadThread(self.upload_manager, file_path, enabled_hosts)
        thread.progress_updated.connect(self.on_progress_updated)
        thread.host_upload_completed.connect(self.on_host_upload_completed)
        thread.upload_completed.connect(self.on_upload_completed)
        thread.finished.connect(lambda: self.cleanup_thread(thread))
        
        self.upload_threads.append(thread)
        thread.start()
        
    def cleanup_thread(self, thread):
        if thread in self.upload_threads:
            self.upload_threads.remove(thread)

    def _construct_download_link(self, host_name: str, file_id: Optional[str]) -> Optional[str]:
        """Construct download link from file_id for known hosts."""
        if not file_id:
            return None
        host_lower = host_name.lower()
        if "up-4ever" in host_lower or "up4ever" in host_lower:
            return f"https://www.up-4ever.net/{file_id}"
        if "send.now" in host_lower or "send now" in host_lower:
            return f"https://send.cm/{file_id}"
        if "cloudfam" in host_lower:
            return f"https://cloudfam.io/{file_id}"
        if "mega4upload" in host_lower:
            return f"https://mega4upload.net/{file_id}"
        if "upfiles" in host_lower:
            return f"https://upfiles.com/{file_id}"
        return None

    def on_host_upload_completed(self, file_name: str, host_name: str, result: UploadResult):
        """Handle individual host upload completion immediately."""
        try:
            key = (file_name, host_name)
            if key not in self.upload_rows:
                return
            row = self.upload_rows[key]

            if result.status == UploadStatus.COMPLETED:
                self.upload_table.item(row, 3).setText("✅ Completed")
                self.upload_table.item(row, 3).setForeground(Qt.darkGreen)

                # Use download_link from result, or construct from file_id as fallback
                download_link = result.download_link
                if not download_link and result.file_id:
                    download_link = self._construct_download_link(host_name, result.file_id)

                if download_link:
                    self.upload_table.setItem(row, 6, QTableWidgetItem(download_link))
                    self.upload_table.item(row, 6).setForeground(Qt.blue)

                    # Save link to links.txt
                    try:
                        links_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'links.txt')
                        with open(links_file, "a", encoding="utf-8") as f:
                            f.write(download_link + "\n")
                    except Exception as e:
                        print(f"Error saving link to file: {e}")
                else:
                    # Show indicator that upload succeeded but link unavailable
                    self.upload_table.setItem(row, 6, QTableWidgetItem("✓ Uploaded (no link)"))
                    self.upload_table.item(row, 6).setForeground(Qt.gray)

                progress_bar = self.upload_table.cellWidget(row, 5)
                if isinstance(progress_bar, QProgressBar):
                    progress_bar.setValue(100)
                    progress_bar.setStyleSheet(PROGRESS_BAR_STYLE.replace("#2196F3", "#4CAF50"))
            else:
                error_msg = result.error_message or "Unknown Error"
                if "Cancelled" in error_msg:
                    self.upload_table.item(row, 3).setText("⏹ Cancelled")
                    self.upload_table.item(row, 3).setForeground(Qt.darkRed)
                else:
                    self.upload_table.item(row, 3).setText(f"❌ Failed: {error_msg}")
                    self.upload_table.item(row, 3).setForeground(Qt.red)

                progress_bar = self.upload_table.cellWidget(row, 5)
                if isinstance(progress_bar, QProgressBar):
                    progress_bar.setStyleSheet(PROGRESS_BAR_STYLE.replace("#2196F3", "#f44336"))
        except Exception as e:
            print(f"[MainWindow] ERROR in on_host_upload_completed: {e}")
            import traceback
            traceback.print_exc()
        
        if result.status == UploadStatus.COMPLETED:
            self.upload_table.item(row, 3).setText("✅ Completed")
            self.upload_table.item(row, 3).setForeground(Qt.darkGreen)
            
            # Use download_link from result, or construct from file_id as fallback
            download_link = result.download_link
            if not download_link and result.file_id:
                download_link = self._construct_download_link(host_name, result.file_id)
            
            if download_link:
                self.upload_table.setItem(row, 6, QTableWidgetItem(download_link))
                self.upload_table.item(row, 6).setForeground(Qt.blue)
                
                # Save link to links.txt
                try:
                    links_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'links.txt')
                    with open(links_file, "a", encoding="utf-8") as f:
                        f.write(download_link + "\n")
                except Exception as e:
                    print(f"Error saving link to file: {e}")
            else:
                # Show indicator that upload succeeded but link unavailable
                self.upload_table.setItem(row, 6, QTableWidgetItem("✓ Uploaded (no link)"))
                self.upload_table.item(row, 6).setForeground(Qt.gray)
            
            progress_bar = self.upload_table.cellWidget(row, 5)
            if isinstance(progress_bar, QProgressBar):
                progress_bar.setValue(100)
                progress_bar.setStyleSheet(PROGRESS_BAR_STYLE.replace("#2196F3", "#4CAF50"))
        else:
            error_msg = result.error_message or "Unknown Error"
            if "Cancelled" in error_msg:
                    self.upload_table.item(row, 3).setText("⏹ Cancelled")
                    self.upload_table.item(row, 3).setForeground(Qt.darkRed)
            else:
                self.upload_table.item(row, 3).setText(f"❌ Failed: {error_msg}")
                self.upload_table.item(row, 3).setForeground(Qt.red)
            
            progress_bar = self.upload_table.cellWidget(row, 5)
            if isinstance(progress_bar, QProgressBar):
                progress_bar.setStyleSheet(PROGRESS_BAR_STYLE.replace("#2196F3", "#f44336"))

    def get_selected_tasks(self):
        """Get list of (file_name, host, row, file_path) for selected rows."""
        selected_rows = set()
        for range_ in self.upload_table.selectedRanges():
            for row in range(range_.topRow(), range_.bottomRow() + 1):
                selected_rows.add(row)
        
        tasks = []
        for row in selected_rows:
            file_item = self.upload_table.item(row, 0)
            host_item = self.upload_table.item(row, 2)
            if file_item and host_item:
                file_name = file_item.text()
                host = host_item.text()
                file_path = file_item.data(Qt.UserRole)
                tasks.append((file_name, host, row, file_path))
        return tasks

    def get_thread_for_file(self, file_name):
        """Find active thread for a file."""
        for thread in self.upload_threads:
            if thread.file_name == file_name:
                return thread
        return None

    def pause_selected(self):
        """Pause uploads for selected rows."""
        tasks = self.get_selected_tasks()
        for file_name, _, row, _ in tasks:
            thread = self.get_thread_for_file(file_name)
            if thread:
                thread.pause()
                self.upload_table.item(row, 3).setText("⏸ Paused")
                self.statusBar().showMessage(f"Paused upload for {file_name}", 2000)

    def stop_selected(self):
        """Stop/Cancel uploads for selected rows."""
        tasks = self.get_selected_tasks()
        for file_name, host, row, _ in tasks:
            thread = self.get_thread_for_file(file_name)
            if thread:
                thread.cancel_host(host)
                self.upload_table.item(row, 3).setText("Stopping...")
                self.statusBar().showMessage(f"Stopping {host} upload for {file_name}", 2000)

    def reupload_selected(self):
        """Re-upload selected files/hosts."""
        tasks = self.get_selected_tasks()
        for file_name, host, row, file_path in tasks:
            thread = self.get_thread_for_file(file_name)
            if thread and host not in thread._cancelled_hosts:
                 pass
            
            if file_path and Path(file_path).exists():
                self.upload_table.item(row, 3).setText("Pending")
                self.upload_table.item(row, 4).setText("0 KB/s")
                
                # Reset progress bar value AND color
                progress_bar = self.upload_table.cellWidget(row, 5)
                if isinstance(progress_bar, QProgressBar):
                    progress_bar.setValue(0)
                    # Reset to default blue color (remove red color from failed upload)
                    progress_bar.setStyleSheet(PROGRESS_BAR_STYLE)
                
                self.upload_table.item(row, 6).setText("")
                
                thread = UploadThread(self.upload_manager, file_path, [host])
                thread.progress_updated.connect(self.on_progress_updated)
                thread.upload_completed.connect(self.on_upload_completed)
                thread.host_upload_completed.connect(self.on_host_upload_completed)
                thread.finished.connect(lambda t=thread: self.cleanup_thread(t))
                
                self.upload_rows[(file_name, host)] = row
                self.upload_start_times[(file_name, host)] = time.time()
                self._initial_bytes.pop((file_name, host), None) # Clear initial bytes for new upload
                
                self.upload_threads.append(thread)
                thread.start()
                
    def on_progress_updated(self, file_name: str, host_name: str, progress: int, bytes_read: int):
        """Handle progress update."""
        key = (file_name, host_name)
        if key in self.upload_rows:
            row = self.upload_rows[key]
            
            # Check if paused (don't overwrite 'Paused' status if thread is actually paused)
            # But the thread sends updates. If paused, it won't send updates. 
            # So if we receive an update, it means we are uploading.
            
            progress_bar = self.upload_table.cellWidget(row, 5)
            if isinstance(progress_bar, QProgressBar):
                progress_bar.setValue(progress)
            
            total_size = self.file_sizes.get(file_name, 0)
            size_detail = f"{self.format_size(bytes_read)} / {self.format_size(total_size)}"
            self.upload_table.item(row, 1).setText(size_detail)
            
            self.upload_table.item(row, 3).setText("Uploading...")
            
            start_time = self.upload_start_times.get(key)
            if start_time:
                elapsed = time.time() - start_time
                if elapsed > 0 and bytes_read > 0:
                    if key not in self._initial_bytes:
                        self._initial_bytes[key] = bytes_read
                    
                    actual_uploaded = max(0, bytes_read - self._initial_bytes[key])
                    speed = actual_uploaded / elapsed
                    self.upload_table.item(row, 4).setText(f"{self.format_size(speed)}/s")
    
    def on_upload_completed(self, file_name: str, job: UploadJob):
        """Handle upload completion."""
        # Logic moved to on_host_upload_completed to support immediate updates
        pass
    
    def closeEvent(self, event):
        """Handle window close event."""
        for thread in self.upload_threads:
            thread.wait()
        event.accept()
