# Multi-File Hosting Uploader - Quick Start

## ✅ Aplikasi Sudah Siap Digunakan!

### Cara Menjalankan

```bash
cd c:\laragon\www\multiuploader
python main.py
```

### Setup Pertama Kali

#### 1. CloudFam (API)

1. Klik tombol **⚙ Settings**
2. Pilih tab **CloudFam**
3. Centang "Enable CloudFam"
4. Masukkan API Key dari https://cloudfam.io/dashboard
5. Klik **Test API Key**
6. Klik **Save**

#### 2. Up-4ever (Cookies)

1. Di tab **Up-4ever**
2. Centang "Enable Up-4ever"
3. **Cara 1 - Import File:**
   - Export cookies dari browser (gunakan extension seperti "EditThisCookie")
   - Klik **Import Cookies File**
   - Pilih file cookies.json
4. **Cara 2 - Paste Manual:**
   - Paste cookies dalam format JSON:
   ```json
   {
     "xfss": "your_cookie_value_here",
     "login": "your_login_cookie"
   }
   ```
5. Klik **Test Cookies**
6. Klik **Save**

### Upload File

1. **Drag & Drop** file ke area upload, atau klik **Browse Files**
2. File otomatis upload ke semua hosting yang aktif
3. Tunggu sampai progress bar selesai
4. Download links muncul di panel kanan
5. Klik **📋** untuk copy link, atau **📋 Copy All Links** untuk copy semua

### Tips Export Cookies dari Browser

#### Chrome/Edge:
1. Install extension "EditThisCookie" atau "Cookie-Editor"
2. Buka https://www.up-4ever.net dan login
3. Klik icon extension
4. Export cookies sebagai JSON
5. Save file atau copy JSON

#### Firefox:
1. Install addon "Cookie-Editor"
2. Login ke up-4ever.net
3. Klik icon addon
4. Export All → JSON
5. Save atau copy

### Build ke .EXE

Untuk membuat file executable yang bisa dijalankan tanpa Python:

```bash
python build.py
```

File .exe akan ada di folder `dist/MultiUploader.exe`

### Troubleshooting

**Q: Upload gagal ke Up-4ever?**
- Cookies mungkin expired, export ulang cookies baru

**Q: CloudFam error "Invalid API Key"?**
- Pastikan API key benar
- Cek di dashboard CloudFam apakah API key masih aktif

**Q: Aplikasi tidak muncul?**
- Pastikan Python sudah terinstall
- Cek apakah ada error di terminal

### File Penting

- `main.py` - Jalankan aplikasi
- `data/credentials.json` - Menyimpan API key & cookies (JANGAN SHARE!)
- `data/settings.json` - Pengaturan aplikasi
- `PANDUAN.md` - Panduan lengkap bahasa Indonesia
- `README.md` - Dokumentasi lengkap

### Fitur

✅ Upload ke multiple hosting sekaligus
✅ Progress tracking real-time per hosting
✅ Download links otomatis muncul
✅ Copy link dengan 1 klik
✅ Data portable (bisa dipindah folder/komputer)
✅ Settings tersimpan otomatis

---

**Selamat menggunakan! 🚀**

Jika ada masalah, cek file `PANDUAN.md` untuk panduan lengkap.
