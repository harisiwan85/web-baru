"""Multi-File Hosting Uploader - Main Entry Point."""
import sys
from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui import QIcon
from app.main_window import MainWindow


def main():
    """Main application entry point."""
    app = QApplication(sys.argv)
    app.setApplicationName("Multi-File Hosting Uploader")
    app.setOrganizationName("FileUploader")
    
    # Set application style
    app.setStyle("Fusion")
    
    # Create and show main window
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
