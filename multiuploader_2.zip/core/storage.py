"""Portable data storage manager."""
import json
import os
from pathlib import Path
from typing import Dict, List, Optional
from core.models import HostConfig


class StorageManager:
    """Manages persistent storage of credentials and settings."""
    
    def __init__(self):
        """Initialize storage manager."""
        # Get the directory where the executable/script is located
        if getattr(sys, 'frozen', False):
            # Running as compiled executable
            self.app_dir = Path(sys.executable).parent
        else:
            # Running as script
            self.app_dir = Path(__file__).parent.parent
        
        self.data_dir = self.app_dir / 'data'
        self.credentials_file = self.data_dir / 'credentials.json'
        self.settings_file = self.data_dir / 'settings.json'
        
        # Create data directory if it doesn't exist
        self.data_dir.mkdir(exist_ok=True)
        
        # Initialize default data
        self._ensure_files_exist()
    
    def _ensure_files_exist(self):
        """Create default files if they don't exist."""
        if not self.credentials_file.exists():
            self.save_credentials({})
        
        if not self.settings_file.exists():
            default_settings = {
                'hosts': self._get_default_hosts(),
                'last_upload_dir': str(Path.home())
            }
            self.save_settings(default_settings)
    
    def _get_default_hosts(self) -> List[dict]:
        """Get default host configurations."""
        from core.models import HostType, AuthMethod
        
        return [
            {
                'name': 'CloudFam',
                'host_type': HostType.CLOUDFAM.value,
                'enabled': True,
                'auth_method': AuthMethod.API_KEY.value,
                'credentials': {}
            },
            {
                'name': 'Up-4ever',
                'host_type': HostType.UP4EVER.value,
                'enabled': True,
                'auth_method': AuthMethod.COOKIES.value,
                'credentials': {}
            },
            {
                'name': 'Up-4ever API',
                'host_type': HostType.UP4EVER_API.value,
                'enabled': True,
                'auth_method': AuthMethod.API_KEY.value,
                'credentials': {}
            },
            {
                'name': 'Mega4Upload',
                'host_type': HostType.MEGA4UPLOAD.value,
                'enabled': True,
                'auth_method': AuthMethod.COOKIES.value,
                'credentials': {}
            },
            {
                'name': 'Mega4Upload API',
                'host_type': HostType.MEGA4UPLOAD_API.value,
                'enabled': True,
                'auth_method': AuthMethod.API_KEY.value,
                'credentials': {}
            },
            {
                'name': 'Upfiles',
                'host_type': HostType.UPFILES.value,
                'enabled': True,
                'auth_method': AuthMethod.API_KEY.value,
                'credentials': {}
            },
            {
                'name': 'send.now',
                'host_type': HostType.SEND_NOW.value,
                'enabled': True,
                'auth_method': AuthMethod.API_KEY.value,
                'credentials': {}
            },
        ]
    
    def load_credentials(self) -> Dict:
        """Load credentials from file."""
        try:
            with open(self.credentials_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}
    
    def save_credentials(self, credentials: Dict):
        """Save credentials to file."""
        with open(self.credentials_file, 'w', encoding='utf-8') as f:
            json.dump(credentials, f, indent=2)
    
    def load_settings(self) -> Dict:
        """Load settings from file."""
        try:
            with open(self.settings_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {'hosts': self._get_default_hosts()}
    
    def save_settings(self, settings: Dict):
        """Save settings to file."""
        with open(self.settings_file, 'w', encoding='utf-8') as f:
            json.dump(settings, f, indent=2)
    
    def get_host_configs(self) -> List[HostConfig]:
        """Get all host configurations.
        
        This will merge any missing default hosts into the current settings.
        """
        settings = self.load_settings()
        hosts_data = settings.get('hosts', [])
        
        # Check for missing default hosts
        default_hosts = self._get_default_hosts()
        existing_host_types = [h.get('host_type') for h in hosts_data]
        
        modified = False
        for default_host in default_hosts:
            if default_host.get('host_type') not in existing_host_types:
                hosts_data.append(default_host)
                modified = True
        
        if modified:
            settings['hosts'] = hosts_data
            self.save_settings(settings)
            
        return [HostConfig.from_dict(h) for h in hosts_data]
    
    def save_host_configs(self, configs: List[HostConfig]):
        """Save host configurations."""
        settings = self.load_settings()
        settings['hosts'] = [c.to_dict() for c in configs]
        self.save_settings(settings)
    
    def get_host_credentials(self, host_name: str) -> Optional[Dict]:
        """Get credentials for a specific host."""
        credentials = self.load_credentials()
        return credentials.get(host_name)
    
    def save_host_credentials(self, host_name: str, credentials: Dict):
        """Save credentials for a specific host."""
        all_credentials = self.load_credentials()
        all_credentials[host_name] = credentials
        self.save_credentials(all_credentials)
    
    def get_last_upload_dir(self) -> str:
        """Get last used upload directory."""
        settings = self.load_settings()
        return settings.get('last_upload_dir', str(Path.home()))
    
    def save_last_upload_dir(self, directory: str):
        """Save last used upload directory."""
        settings = self.load_settings()
        settings['last_upload_dir'] = directory
        self.save_settings(settings)


import sys
