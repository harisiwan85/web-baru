"""Data models for the application."""
from dataclasses import dataclass, field
from typing import Optional, Dict, Any
from enum import Enum


class HostType(Enum):
    """Types of file hosting services."""
    CLOUDFAM = "cloudfam"
    UP4EVER = "up4ever"
    UP4EVER_API = "up4ever_api"
    MEGA4UPLOAD = "mega4upload"
    MEGA4UPLOAD_API = "mega4upload_api"
    UPFILES = "upfiles"
    SEND_NOW = "send_now"


class AuthMethod(Enum):
    """Authentication methods."""
    API_KEY = "api_key"
    COOKIES = "cookies"
    WEB_LOGIN = "web_login"


class UploadStatus(Enum):
    """Upload status."""
    PENDING = "pending"
    UPLOADING = "uploading"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class HostConfig:
    """Configuration for a file hosting service."""
    name: str
    host_type: HostType
    enabled: bool = True
    auth_method: AuthMethod = AuthMethod.API_KEY
    credentials: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            'name': self.name,
            'host_type': self.host_type.value,
            'enabled': self.enabled,
            'auth_method': self.auth_method.value,
            'credentials': self.credentials
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'HostConfig':
        """Create from dictionary."""
        return cls(
            name=data['name'],
            host_type=HostType(data['host_type']),
            enabled=data.get('enabled', True),
            auth_method=AuthMethod(data.get('auth_method', 'api_key')),
            credentials=data.get('credentials', {})
        )


@dataclass
class UploadResult:
    """Result of a file upload."""
    host_name: str
    status: UploadStatus
    download_link: Optional[str] = None
    error_message: Optional[str] = None
    file_id: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            'host_name': self.host_name,
            'status': self.status.value,
            'download_link': self.download_link,
            'error_message': self.error_message,
            'file_id': self.file_id
        }


@dataclass
class UploadJob:
    """Represents a file upload job."""
    file_path: str
    file_name: str
    file_size: int
    hosts: list[str]  # List of host names to upload to
    results: Dict[str, UploadResult] = field(default_factory=dict)
    overall_status: UploadStatus = UploadStatus.PENDING
    
    def add_result(self, result: UploadResult):
        """Add an upload result for a specific host."""
        self.results[result.host_name] = result
        self._update_overall_status()
    
    def _update_overall_status(self):
        """Update overall status based on individual results."""
        if not self.results:
            self.overall_status = UploadStatus.PENDING
            return
        
        statuses = [r.status for r in self.results.values()]
        
        if all(s == UploadStatus.COMPLETED for s in statuses):
            self.overall_status = UploadStatus.COMPLETED
        elif any(s == UploadStatus.UPLOADING for s in statuses):
            self.overall_status = UploadStatus.UPLOADING
        elif all(s == UploadStatus.FAILED for s in statuses):
            self.overall_status = UploadStatus.FAILED
        else:
            self.overall_status = UploadStatus.UPLOADING
