"""Upload manager for orchestrating multi-host uploads."""
import os
from pathlib import Path
from typing import List, Callable, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import deque
from core.models import UploadJob, UploadResult, UploadStatus, HostConfig
from uploaders.cloudfam import CloudFamUploader
from uploaders.up4ever import Up4EverUploader
from uploaders.up4ever_api import Up4EverApiUploader
from uploaders.mega4upload import Mega4UploadUploader
from uploaders.mega4upload_api import Mega4UploadApiUploader
from uploaders.upfiles import UpfilesUploader
from uploaders.send_now import SendNowUploader


class UploadManager:
    """Manages uploads to multiple hosts with queue support."""

    def __init__(self, storage_manager):
        """Initialize upload manager.

        Args:
            storage_manager: StorageManager instance
        """
        self.storage = storage_manager
        self._uploaders = {}
        self._initialize_uploaders()
        # Queue settings
        self._max_concurrent = 2
        self._active_uploads = 0
        self._queue_paused = False
        self._current_job = None
        self._host_queue = []  # List of host names waiting to upload
        self._executor = ThreadPoolExecutor(max_workers=10)  # Max possible hosts

    def _initialize_uploaders(self):
        """Initialize uploader instances."""
        self._uploaders = {
            'CloudFam': CloudFamUploader(),
            'Up-4ever': Up4EverUploader(),
            'Up-4ever API': Up4EverApiUploader(),
            'send.now': SendNowUploader(),
            'Mega4Upload': Mega4UploadUploader(),
            'Mega4Upload API': Mega4UploadApiUploader(),
            'Upfiles': UpfilesUploader()
        }

    def get_uploader(self, host_name: str):
        """Get uploader instance for a host.

        Args:
            host_name: Name of the host

        Returns:
            Uploader instance or None
        """
        return self._uploaders.get(host_name)

    def authenticate_host(self, host_name: str, credentials: dict) -> bool:
        """Authenticate with a specific host.

        Args:
            host_name: Name of the host
            credentials: Authentication credentials

        Returns:
            True if authentication successful
        """
        uploader = self.get_uploader(host_name)
        if not uploader:
            return False

        success = uploader.authenticate(credentials)
        if success:
            # Save credentials
            self.storage.save_host_credentials(host_name, credentials)

        return success

    def apply_host_credentials(self, host_name: str, credentials: dict):
        """Apply credentials without validation.

        Args:
            host_name: Name of the host
            credentials: Authentication credentials
        """
        uploader = self.get_uploader(host_name)
        if uploader:
            uploader.set_credentials(credentials)
            # Save credentials
            self.storage.save_host_credentials(host_name, credentials)

    def load_saved_credentials(self):
        """Load and apply saved credentials without network validation."""
        for host_name, uploader in self._uploaders.items():
            credentials = self.storage.get_host_credentials(host_name)
            if credentials:
                # Use set_credentials instead of authenticate for faster startup
                # No network validation during app initialization
                uploader.set_credentials(credentials)

    def set_queue_concurrency(self, max_concurrent: int):
        """Set maximum concurrent uploads.

        Args:
            max_concurrent: Maximum number of simultaneous uploads (1-10)
        """
        self._max_concurrent = max(1, min(10, max_concurrent))

    def get_queue_concurrency(self) -> int:
        """Get current max concurrent uploads setting."""
        return self._max_concurrent

    def upload_file(self, file_path: str, enabled_hosts: List[str],
                   progress_callback: Optional[Callable[[str, int], None]] = None,
                   completion_callback: Optional[Callable[[UploadJob], None]] = None,
                   cancel_check_callback: Optional[Callable[[str], bool]] = None,
                   host_completion_callback: Optional[Callable[[str, UploadResult], None]] = None) -> UploadJob:
        """Upload a file to multiple hosts with queue support."""
        file_path_obj = Path(file_path)
        job = UploadJob(
            file_path=file_path,
            file_name=file_path_obj.name,
            file_size=file_path_obj.stat().st_size,
            hosts=enabled_hosts
        )
        self._current_job = job

        # Load queue settings from storage
        settings = self.storage.load_settings()
        queue_settings = settings.get('queue', {})
        self._max_concurrent = queue_settings.get('max_concurrent', 2)

        # Initialize queue
        self._host_queue = enabled_hosts.copy()
        self._active_uploads = 0
        self._queue_paused = False

        # Start initial uploads up to max_concurrent
        self._start_next_in_queue(job, progress_callback, completion_callback,
                                 cancel_check_callback, host_completion_callback)

        return job

    def _start_next_in_queue(self, job: UploadJob,
                            progress_callback: Optional[Callable[[str, int], None]] = None,
                            completion_callback: Optional[Callable[[UploadJob], None]] = None,
                            cancel_check_callback: Optional[Callable[[str], bool]] = None,
                            host_completion_callback: Optional[Callable[[str, UploadResult], None]] = None):
        """Start next upload from queue if slots available."""
        while (self._active_uploads < self._max_concurrent and self._host_queue
               and not self._queue_paused):
            host_name = self._host_queue.pop(0)
            uploader = self.get_uploader(host_name)
            if not uploader or not uploader.is_authenticated():
                result = UploadResult(
                    host_name=host_name,
                    status=UploadStatus.FAILED,
                    error_message="Uploader not found or not authenticated"
                )
                job.add_result(result)
                if host_completion_callback:
                    host_completion_callback(host_name, result)
                continue

            self._active_uploads += 1
            self._submit_host_upload(job, host_name, uploader, progress_callback,
                                    host_completion_callback, cancel_check_callback,
                                    completion_callback)

    def _submit_host_upload(self, job: UploadJob, host_name: str, uploader,
                           progress_callback, host_completion_callback, cancel_check_callback,
                           completion_callback):
        """Submit a single host upload to executor."""
        def make_host_progress_callback(host):
            def callback(progress):
                if progress_callback:
                    progress_callback(host, progress)
            return callback

        def check_cancel():
            if cancel_check_callback:
                return cancel_check_callback(host_name)
            return False

        future = self._executor.submit(
            uploader.upload,
            job.file_path,
            make_host_progress_callback(host_name),
            check_cancel
        )
        future.add_done_callback(
            lambda f: self._on_host_finished(job, host_name, f, completion_callback,
                                            host_completion_callback, progress_callback,
                                            cancel_check_callback)
        )

    def _on_host_finished(self, job: UploadJob, host_name: str, future,
                         completion_callback, host_completion_callback,
                         progress_callback, cancel_check_callback):
        """Handle host upload completion."""
        try:
            result = future.result()
            job.add_result(result)
        except Exception as e:
            result = UploadResult(
                host_name=host_name,
                status=UploadStatus.FAILED,
                error_message=f"Upload exception: {str(e)}"
            )
            job.add_result(result)

        if host_completion_callback:
            host_completion_callback(host_name, result)

        self._active_uploads -= 1

        # Check if job is complete
        if len(job.results) >= len(job.hosts):
            if completion_callback:
                completion_callback(job)
        else:
            # Start next in queue
            self._start_next_in_queue(job, progress_callback, completion_callback,
                                     cancel_check_callback, host_completion_callback)

    def pause_queue(self):
        """Pause the upload queue."""
        self._queue_paused = True

    def resume_queue(self):
        """Resume the upload queue."""
        self._queue_paused = False
        if self._current_job:
            self._start_next_in_queue(self._current_job)

    def cancel_all(self):
        """Cancel all queued and active uploads."""
        self._queue_paused = True
        self._host_queue.clear()
        # Note: Active uploads will finish but won't start new ones

    def get_enabled_hosts(self) -> List[str]:
        """Get list of enabled host names.

        Returns:
            List of enabled host names
        """
        configs = self.storage.get_host_configs()
        return [c.name for c in configs if c.enabled]

    def is_host_authenticated(self, host_name: str) -> bool:
        """Check if a host is authenticated.

        Args:
            host_name: Name of the host

        Returns:
            True if authenticated
        """
        uploader = self.get_uploader(host_name)
        if not uploader:
            return False
        return uploader.is_authenticated()