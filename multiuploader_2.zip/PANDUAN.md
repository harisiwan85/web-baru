# Cara Menggunakan Multi-File Hosting Uploader

## Panduan Lengkap (Bahasa Indonesia)

### Instalasi

1. **Install Python Dependencies**
   ```bash
   cd c:\laragon\www\multiuploader
   python -m pip install -r requirements.txt
   ```

2. **Jalankan Aplikasi**
   ```bash
   python main.py
   ```

### Konfigurasi Awal

#### CloudFam (Menggunakan API)

1. Buka **Settings** di aplikasi
2. Pilih tab **CloudFam**
3. Centang "Enable CloudFam"
4. Masukkan API Key Anda dari dashboard CloudFam
5. Klik **Test API Key** untuk verifikasi
6. Klik **Save**

**Cara Mendapatkan API Key:**
- Login ke https://cloudfam.io
- Buka dashboard/settings
- Copy API key Anda

#### Up-4ever (Menggunakan Cookies)

1. Buka **Settings** di aplikasi
2. Pilih tab **Up-4ever**
3. Centang "Enable Up-4ever"
4. Ada 2 cara input cookies:

**Cara 1: Import File Cookies**
- Export cookies dari browser menggunakan extension (contoh: "EditThisCookie", "Cookie-Editor")
- Klik **Import Cookies File**
- Pilih file cookies yang sudah di-export
- Klik **Test Cookies**
- Klik **Save**

**Cara 2: Paste Manual**
- Login ke https://www.up-4ever.net di browser
- Export cookies dalam format JSON
- Paste di text area dengan format:
  ```json
  {
    "cookie_name": "cookie_value",
    "another_cookie": "another_value"
  }
  ```
- Klik **Test Cookies**
- Klik **Save**

### Upload File

1. **Pilih File:**
   - Drag & drop file ke area upload, ATAU
   - Klik tombol **Browse Files**

2. **Proses Upload:**
   - File otomatis upload ke semua hosting yang aktif
   - Progress bar menunjukkan status upload per hosting
   - Tunggu sampai selesai

3. **Ambil Link Download:**
   - Link download muncul di panel kanan
   - Klik tombol 📋 untuk copy link individual
   - Klik **Copy All Links** untuk copy semua link sekaligus

### Versi CLI (Linux Server / Tanpa GUI)

Selain versi desktop, tersedia `cli.py` untuk dipakai di server Linux tanpa tampilan grafis. CLI memakai logika dan folder `data/` yang sama dengan versi desktop, dan **tidak butuh PyQt5**.

**Instalasi di Linux:**
```bash
cd multiuploader
python3 -m pip install -r requirements-cli.txt
```

**Melihat daftar hosting & status:**
```bash
python3 cli.py hosts
```

**Menyimpan kredensial:**
```bash
# Hosting berbasis API key
python3 cli.py set CloudFam --api-key API_KEY_ANDA
python3 cli.py set "Up-4ever API" --api-key API_KEY_ANDA

# Hosting berbasis cookies (file export browser, format JSON dict/list)
python3 cli.py set Up-4ever --cookies-file cookies.json
# atau inline: JSON, maupun format header "nama=nilai; nama2=nilai2"
python3 cli.py set Up-4ever --cookies "pf_session=abc; uid=42"

# Hapus kredensial
python3 cli.py set Up-4ever --clear
```

**Uji kredensial:**
```bash
python3 cli.py test CloudFam
```

**Mengaktifkan / menonaktifkan hosting:**
```bash
python3 cli.py enable Up-4ever
python3 cli.py disable send.now
```

**Upload file:**
```bash
python3 cli.py upload video.mp4
python3 cli.py upload a.zip b.zip --hosts "CloudFam,Up-4ever"
python3 cli.py upload video.mp4 --output hasil.json   # simpan hasil ke file JSON
python3 cli.py upload video.mp4 --json                # output JSON untuk scripting
python3 cli.py upload video.mp4 --quiet               # tanpa progress bar
```

**Kode keluar (exit code):** `0` = semua berhasil, `1` = ada yang gagal, `2` = kesalahan perintah, `130` = dibatalkan (Ctrl+C). Cocok untuk cron/script, contoh backup harian:

```bash
0 3 * * * cd /opt/multiuploader && python3 cli.py upload /data/backup_$(date +\%F).tar.gz --output /var/log/uploader_$(date +\%F).json
```

**Tips portabilitas:** kredensial tersimpan di `data/credentials.json`, folder yang sama dengan versi desktop. Anda bisa mengonfigurasi kredensial di Windows (via GUI atau CLI), lalu menyalin seluruh folder aplikasi ke Linux — semua kredensial ikut terbawa.

### Build Executable (.exe)

Untuk membuat file .exe yang bisa dijalankan tanpa Python:

```bash
python build.py
```

File .exe akan dibuat di folder `dist/MultiUploader.exe`

### Troubleshooting

**Problem: "DLL load failed" saat jalankan aplikasi**
- Install Visual C++ Redistributable dari Microsoft
- Atau langsung build ke .exe (PyInstaller akan bundle semua DLL)

**Problem: Upload gagal ke Up-4ever**
- Cookies mungkin expired
- Login ulang ke up-4ever.net
- Export cookies baru dan import lagi

**Problem: API key CloudFam tidak valid**
- Pastikan API key benar
- Cek apakah API key masih aktif di dashboard CloudFam

### Tips

1. **Portabilitas:**
   - Semua data tersimpan di folder `data/`
   - Bisa copy seluruh folder aplikasi ke komputer lain
   - Settings dan credentials tetap tersimpan

2. **Keamanan:**
   - Jangan share file `data/credentials.json` (berisi API key dan cookies)
   - Backup credentials secara terpisah

3. **Multiple Files:**
   - Bisa upload banyak file sekaligus
   - Semua file akan di-upload parallel ke semua hosting

## Struktur Data

```
multiuploader/
├── data/
│   ├── credentials.json    # API keys & cookies (JANGAN SHARE!)
│   └── settings.json        # Pengaturan aplikasi
├── dist/                    # Folder executable (setelah build)
├── main.py                  # File utama
└── ...
```

## Contoh Penggunaan

1. Aktifkan CloudFam dan Up-4ever di Settings
2. Drag file `video.mp4` ke aplikasi
3. File otomatis upload ke kedua hosting
4. Setelah selesai, dapat 2 link download:
   - CloudFam: https://cloudfam.io/abc123
   - Up-4ever: https://www.up-4ever.net/xyz789
5. Copy semua link dan share!
