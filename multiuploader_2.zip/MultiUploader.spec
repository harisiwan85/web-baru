# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for MultiUploader.

Optimized for a small one-file EXE:
  - only PyQt5 QtCore/QtGui/QtWidgets DLLs are bundled (no Qml/Quick/Network/WebSockets/Svg/DBus)
  - only the Qt plugins the app actually needs (qwindows, qico, qwindowsvistastyle)
  - no OpenGL/ANGLE DLLs (app renders with the raster backend)
  - unused heavy packages are excluded (PyQtWebEngine, selenium, numpy, PyQt6, ...)
"""

import os

block_cipher = None

datas = [('icon.ico', '.')]

excludes = [
    # Qt modules the app does not import
    'PyQt5.Qt', 'PyQt5.QtNetwork', 'PyQt5.QtQml', 'PyQt5.QtQuick',
    'PyQt5.QtQuickWidgets', 'PyQt5.QtWebSockets', 'PyQt5.QtSvg',
    'PyQt5.QtDBus', 'PyQt5.QtOpenGL', 'PyQt5.QtPrintSupport', 'PyQt5.QtXml',
    'PyQt5.QtXmlPatterns', 'PyQt5.QtTest', 'PyQt5.QtHelp', 'PyQt5.QtDesigner',
    'PyQt5.QtSql', 'PyQt5.QtMultimedia', 'PyQt5.QtMultimediaWidgets',
    'PyQt5.QtPositioning', 'PyQt5.QtLocation', 'PyQt5.QtWebView',
    'PyQt5.QtWebChannel', 'PyQt5.QtWebEngineWidgets', 'PyQt5.QtWebEngineCore',
    'PyQt5.QtWebEngine', 'PyQt5.QtBluetooth', 'PyQt5.QtNfc', 'PyQt5.QtSensors',
    'PyQt5.QtSerialPort', 'PyQt5.QtNetworkAuth', 'PyQt5.QtRemoteObjects',
    'PyQt5.QtScxml', 'PyQt5.QtScript', 'PyQt5.QtScriptTools',
    'PyQt5.QtTextToSpeech', 'PyQt5.QtUiTools', 'PyQt5.Qt3DCore',
    'PyQt5.Qt3DRender', 'PyQt5.Qt3DExtras', 'PyQt5.QtCharts',
    'PyQt5.QtDataVisualization', 'PyQt5.QtPurchasing', 'PyQt5.QAxContainer',
    # Unused heavy third-party packages installed on the build machine
    'PyQt6', 'PySide2', 'PySide6', 'selenium', 'numpy', 'pandas',
    'matplotlib', 'scipy', 'PIL', 'tkinter',
]

a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excludes,
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

# ---------------------------------------------------------------------------
# Trim Qt binaries: keep only what this app actually uses.
# ---------------------------------------------------------------------------
KEEP_QT_DLLS = {'qt5core.dll', 'qt5gui.dll', 'qt5widgets.dll'}

# Plugins (relative to the "plugins" directory inside PyQt5).
KEEP_PLUGINS = {
    os.path.join('platforms', 'qwindows.dll'),
    os.path.join('imageformats', 'qico.dll'),
    os.path.join('styles', 'qwindowsvistastyle.dll'),
}

# OpenGL/ANGLE/software-renderer DLLs not needed for raster QWidgets rendering.
DROPPED_QT_BIN_DLLS = {
    'libegl.dll', 'libglesv2.dll', 'd3dcompiler_47.dll', 'opengl32sw.dll',
}

filtered_binaries = []
removed = []
for dst, src, typecode in a.binaries:
    base = os.path.basename(dst).lower()

    # Drop unused Qt shared libraries.
    if base.startswith('qt5') and base not in KEEP_QT_DLLS:
        removed.append(dst)
        continue

    # Drop OpenGL/ANGLE support DLLs (Qt raster backend only).
    if base in DROPPED_QT_BIN_DLLS:
        removed.append(dst)
        continue

    # Keep only the Qt plugins the app needs.
    norm = dst.replace('\\', '/')
    if 'plugins' in norm.split('/'):
        parts = norm.split('/')
        idx = parts.index('plugins')
        rel = os.path.join(*parts[idx + 1:])
        if rel.lower() not in KEEP_PLUGINS:
            removed.append(dst)
            continue

    filtered_binaries.append((dst, src, typecode))

a.binaries = filtered_binaries

print('=' * 60)
print('Pruned %d unneeded Qt binaries from the bundle:' % len(removed))
for r in sorted(removed):
    print('  -', os.path.basename(r))
print('=' * 60)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='MultiUploader',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['icon.ico'],
)
