"""Build script for creating a small Windows executable.

Builds from MultiUploader.spec, which prunes unused Qt DLLs/plugins.
If UPX is available at tools/upx/upx.exe, it is used to compress the EXE.
"""
import sys
from pathlib import Path

import PyInstaller.__main__


def build():
    """Build executable using PyInstaller."""
    project_root = Path(__file__).parent

    spec_file = project_root / "MultiUploader.spec"
    upx_dir = project_root / "tools" / "upx"
    upx_exe = upx_dir / "upx.exe"

    args = [
        str(spec_file),
        '--noconfirm',
        '--clean',
    ]

    if upx_exe.exists():
        args.append(f'--upx-dir={upx_dir}')
        print(f"Using UPX from: {upx_exe}")
    else:
        print("UPX not found at tools/upx/upx.exe - building without UPX compression.")

    print("Building executable...")
    print(f"Spec file: {spec_file}")

    PyInstaller.__main__.run(args)

    print("\n" + "=" * 50)
    print("Build completed!")
    print(f"Executable location: {project_root / 'dist' / 'MultiUploader.exe'}")
    print("=" * 50)


if __name__ == "__main__":
    build()
