"""Test script to debug main.py startup."""
import sys
import traceback

try:
    print("Step 1: Importing PyQt5...")
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtGui import QIcon
    print("  ✓ PyQt5 imported")
    
    print("Step 2: Importing MainWindow...")
    from app.main_window import MainWindow
    print("  ✓ MainWindow imported")
    
    print("Step 3: Creating QApplication...")
    app = QApplication(sys.argv)
    app.setApplicationName("Multi-File Hosting Uploader")
    app.setOrganizationName("FileUploader")
    app.setStyle("Fusion")
    print("  ✓ QApplication created")
    
    print("Step 4: Creating MainWindow...")
    window = MainWindow()
    print("  ✓ MainWindow created")
    
    print("Step 5: Showing window...")
    window.show()
    print("  ✓ Window shown")
    
    print("\n✅ All steps completed successfully!")
    print("Application should be visible now...")
    
    sys.exit(app.exec())
    
except Exception as e:
    print(f"\n❌ Error occurred:")
    print(f"Error type: {type(e).__name__}")
    print(f"Error message: {str(e)}")
    print("\nFull traceback:")
    traceback.print_exc()
    sys.exit(1)
