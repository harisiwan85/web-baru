# Multi-File Hosting Uploader

A desktop application for uploading files to multiple file hosting services simultaneously.

## Features

- 📤 Upload files to multiple hosting services at once
- ⚙️ Enable/disable individual hosting services
- 🔐 Multiple authentication methods (API keys, cookies, web login)
- 💾 Portable data storage - credentials persist when moving the application
- 📋 Easy copy download links
- 🎨 Modern, user-friendly interface (PyQt5)

## Supported Hosting Services

1. **CloudFam** - API-based upload
2. **Up-4ever** - Cookie-based upload

## Installation

### From Source

1. Install Python 3.8 or higher
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   python main.py
   ```

### From Executable

1. Download the latest release
2. Run `MultiUploader.exe`
3. All settings and credentials are stored in the `data` folder

## Usage

### Initial Setup

1. Click the **Settings** button
2. For each hosting service:
   - Enable the service
   - Configure authentication:
     - **CloudFam**: Enter your API key
     - **Up-4ever**: Import cookies or paste cookies JSON
   - Click **Test** to verify credentials
3. Click **Save**

### Uploading Files

1. Drag and drop files into the upload area, or click **Browse Files**
2. Files will automatically upload to all enabled hosting services
3. Download links appear in the right panel
4. Click the copy button (📋) to copy individual links
5. Click **Copy All Links** to copy all download links

### Authentication Methods

#### CloudFam (API Key)
- Get your API key from the CloudFam dashboard
- Paste it in the settings

#### Up-4ever (Cookies)
- **Option 1**: Export cookies from your browser using a cookie extension
- **Option 2**: Manually paste cookies in JSON format: `{"cookie_name": "cookie_value"}`
- Import the cookies file or paste directly in settings

## Command Line Interface (CLI)

A GUI-free CLI is included (`cli.py`) for headless Linux servers. It uses the same core logic and `data/` folder as the desktop app and does not require PyQt5:

```bash
pip install -r requirements-cli.txt

# List hosts and their status
python3 cli.py hosts

# Configure credentials
python3 cli.py set CloudFam --api-key YOUR_KEY
python3 cli.py set Up-4ever --cookies-file cookies.json
python3 cli.py set Up-4ever --cookies "pf_session=...; uid=..."
python3 cli.py test CloudFam

# Enable/disable hosts
python3 cli.py enable Up-4ever
python3 cli.py disable send.now

# Upload
python3 cli.py upload video.mp4
python3 cli.py upload a.zip b.zip --hosts "CloudFam,Up-4ever"
python3 cli.py upload video.mp4 --output results.json   # save results as JSON
python3 cli.py upload video.mp4 --json                  # JSON output for scripting
```

Exit codes: `0` = all uploads succeeded, `1` = one or more failed, `2` = usage error, `130` = cancelled (Ctrl+C). Suitable for cron jobs and scripts.

## Building Executable

To build a standalone Windows executable:

```bash
python build.py
```

The executable will be created in the `dist` folder.

## Project Structure

```
multiuploader/
├── app/                    # UI components
│   ├── main_window.py     # Main application window
│   ├── settings_dialog.py # Settings dialog
│   └── widgets/           # Custom widgets
├── core/                   # Core functionality
│   ├── models.py          # Data models
│   ├── storage.py         # Portable storage manager
│   └── upload_manager.py  # Upload orchestration
├── uploaders/             # Host-specific uploaders
│   ├── base.py           # Base uploader interface
│   ├── cloudfam.py       # CloudFam implementation
│   └── up4ever.py        # Up-4ever implementation
├── data/                  # User data (auto-created)
│   ├── credentials.json  # Saved credentials
│   └── settings.json     # Application settings
├── main.py               # GUI entry point
├── cli.py                # CLI entry point (headless servers)
├── build.py              # Build script
└── requirements.txt      # Python dependencies
```

## Data Portability

All user data (credentials, settings) is stored in the `data` folder relative to the executable. You can move the entire application folder to another location or computer, and your settings will be preserved.

## Troubleshooting

### Authentication Issues

- **CloudFam**: Verify your API key is correct and active
- **Up-4ever**: Ensure cookies are not expired. Re-login and export fresh cookies

### Upload Failures

- Check your internet connection
- Verify you're authenticated with the hosting service
- Check file size limits for the hosting service

### Missing Download Links

- Some hosting services may take time to process uploads
- Check the error message in the upload progress area

## License

MIT License

## Support

For issues or questions, please open an issue on GitHub.
